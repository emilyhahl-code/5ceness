import { useEffect, useState, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { Search, Film, Download, Eye, Filter, X, TrendingUp } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Card, Badge, EmptyState } from '@/components/ui';
import { SCENEPACK_CATEGORIES } from '@/types';
import type { Scenepack } from '@/types';

type SortOption = 'newest' | 'downloads' | 'views' | 'trending';

export function ScenepacksPage() {
  const [scenepacks, setScenepacks] = useState<Scenepack[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [sort, setSort] = useState<SortOption>('newest');
  const [showFilters, setShowFilters] = useState(false);

  const fetchScenepacks = useCallback(async () => {
    setLoading(true);
    let query = supabase.from('scenepacks').select('*');
    if (category !== 'All') query = query.eq('category', category);
    if (search.trim()) query = query.or(`title.ilike.%${search}%,description.ilike.%${search}%`);
    switch (sort) {
      case 'downloads': query = query.order('downloads', { ascending: false }); break;
      case 'views': query = query.order('views', { ascending: false }); break;
      case 'trending': query = query.eq('trending', true).order('downloads', { ascending: false }); break;
      default: query = query.order('created_at', { ascending: false });
    }
    const { data } = await query.limit(60);
    setScenepacks(data ?? []);
    setLoading(false);
  }, [category, search, sort]);

  useEffect(() => { fetchScenepacks(); }, [fetchScenepacks]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in">
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold font-display mb-2">Free Scenepacks</h1>
        <p className="text-slate-500">Unlimited free downloads. Browse, filter, and find the perfect pack.</p>
      </div>

      <div className="glass-card p-4 mb-6">
        <div className="flex flex-col md:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input type="text" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search scenepacks..." className="input-field pl-10" />
            {search && <button onClick={() => setSearch('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400"><X className="w-4 h-4" /></button>}
          </div>
          <select value={sort} onChange={(e) => setSort(e.target.value as SortOption)} className="input-field md:w-48">
            <option value="newest">Newest</option>
            <option value="downloads">Most Downloaded</option>
            <option value="views">Most Viewed</option>
            <option value="trending">Trending</option>
          </select>
          <button onClick={() => setShowFilters(!showFilters)} className="btn-secondary flex items-center gap-2 md:w-auto">
            <Filter className="w-4 h-4" /> Filters
          </button>
        </div>
        {showFilters && (
          <div className="mt-4 pt-4 border-t border-slate-200/50 dark:border-slate-700/50 animate-fade-in-down">
            <div className="flex flex-wrap gap-2">
              {SCENEPACK_CATEGORIES.map((cat) => (
                <button key={cat} onClick={() => setCategory(cat)} className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${category === cat ? 'bg-primary-500 text-white shadow-glow-sm' : 'glass hover:bg-primary-50 dark:hover:bg-primary-900/20'}`}>{cat}</button>
              ))}
            </div>
          </div>
        )}
      </div>

      {loading ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {[...Array(8)].map((_, i) => <div key={i} className="h-56 rounded-xl skeleton" />)}
        </div>
      ) : scenepacks.length === 0 ? (
        <EmptyState icon={<Film className="w-8 h-8" />} title="No scenepacks found" message="Try adjusting your search or filters." />
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {scenepacks.map((sp) => (
            <Link key={sp.id} to={`/scenepacks/${sp.id}`}>
              <Card className="!p-0 overflow-hidden h-full">
                <div className="relative h-36 md:h-44 bg-gradient-to-br from-primary-400 to-accent-500">
                  {sp.thumbnail_url ? <img src={sp.thumbnail_url} alt={sp.title} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center"><Film className="w-10 h-10 text-white/70" /></div>}
                  {sp.trending && <div className="absolute top-2 right-2"><Badge variant="warning"><TrendingUp className="w-3 h-3" /> Trending</Badge></div>}
                </div>
                <div className="p-4">
                  <h3 className="font-semibold text-sm truncate">{sp.title}</h3>
                  <p className="text-xs text-slate-500 mb-2">{sp.category}</p>
                  <div className="flex items-center gap-3 text-xs text-slate-400">
                    <span className="flex items-center gap-1"><Download className="w-3 h-3" /> {sp.downloads}</span>
                    <span className="flex items-center gap-1"><Eye className="w-3 h-3" /> {sp.views}</span>
                  </div>
                </div>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
