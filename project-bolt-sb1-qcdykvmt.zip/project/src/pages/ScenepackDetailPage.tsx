import { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Film, Download, Eye, Heart, Star, Share2, Bookmark, ArrowLeft, Crown } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { useLike } from '@/hooks/useLike';
import { CommentSection } from '@/components/CommentSection';
import { Card, Badge, Spinner, EmptyState } from '@/components/ui';
import { Avatar } from '@/components/Avatar';
import type { Scenepack, Profile, Rating } from '@/types';

export function ScenepackDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { session, profile } = useAuth();
  const [scenepack, setScenepack] = useState<Scenepack | null>(null);
  const [creator, setCreator] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [userRating, setUserRating] = useState(0);
  const [avgRating, setAvgRating] = useState(0);
  const [ratingCount, setRatingCount] = useState(0);
  const [favorited, setFavorited] = useState(false);
  const [hoverRating, setHoverRating] = useState(0);
  const [shareCopied, setShareCopied] = useState(false);

  const { liked, likeCount, toggleLike, fetchLikeState } = useLike('scenepack', id!);

  useEffect(() => {
    if (!id) return;
    (async () => {
      const { data, error } = await supabase.from('scenepacks').select('*').eq('id', id).maybeSingle();
      if (error || !data) { setLoading(false); return; }
      const sp = data as Scenepack;
      setScenepack(sp);
      await supabase.from('scenepacks').update({ views: sp.views + 1 }).eq('id', id);

      if (sp.creator_id) {
        const { data: creatorData } = await supabase.from('profiles').select('*').eq('id', sp.creator_id).maybeSingle();
        if (creatorData) setCreator(creatorData as Profile);
      }

      const { data: ratings } = await supabase.from('ratings').select('rating').eq('scenepack_id', id);
      if (ratings && ratings.length > 0) {
        const sum = ratings.reduce((s, r) => s + (r as { rating: number }).rating, 0);
        setAvgRating(sum / ratings.length);
        setRatingCount(ratings.length);
      }

      if (session?.user) {
        const { data: userR } = await supabase.from('ratings').select('rating').eq('scenepack_id', id).eq('user_id', session.user.id).maybeSingle();
        if (userR) setUserRating((userR as { rating: number }).rating);
        const { data: fav } = await supabase.from('favorites').select('id').eq('scenepack_id', id).eq('user_id', session.user.id).maybeSingle();
        setFavorited(!!fav);
      }

      fetchLikeState();
      setLoading(false);
    })();
  }, [id, session?.user, fetchLikeState]);

  const handleDownload = async () => {
    if (!scenepack) return;
    await supabase.from('scenepacks').update({ downloads: scenepack.downloads + 1 }).eq('id', scenepack.id);
    setScenepack({ ...scenepack, downloads: scenepack.downloads + 1 });
    if (scenepack.download_url) window.open(scenepack.download_url, '_blank');
  };

  const handleRate = async (rating: number) => {
    if (!session?.user) return;
    setUserRating(rating);
    const { error } = await supabase.from('ratings').upsert({ scenepack_id: id!, user_id: session.user.id, rating });
    if (!error) {
      const { data: ratings } = await supabase.from('ratings').select('rating').eq('scenepack_id', id!);
      if (ratings && ratings.length > 0) {
        const sum = ratings.reduce((s, r) => s + (r as { rating: number }).rating, 0);
        setAvgRating(sum / ratings.length);
        setRatingCount(ratings.length);
      }
    }
  };

  const handleFavorite = async () => {
    if (!session?.user) return;
    if (favorited) {
      await supabase.from('favorites').delete().eq('scenepack_id', id!).eq('user_id', session.user.id);
      setFavorited(false);
    } else {
      await supabase.from('favorites').insert({ scenepack_id: id! });
      setFavorited(true);
    }
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setShareCopied(true);
    setTimeout(() => setShareCopied(false), 2000);
  };

  if (loading) return <div className="min-h-[60vh] flex items-center justify-center"><Spinner className="w-16 h-16" /></div>;
  if (!scenepack) return <EmptyState icon={<Film className="w-8 h-8" />} title="Scenepack not found" message="This scenepack may have been removed." />;

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in">
      <button onClick={() => navigate(-1)} className="btn-ghost mb-6 flex items-center gap-2 text-sm"><ArrowLeft className="w-4 h-4" /> Back</button>
      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card hover={false} className="!p-0 overflow-hidden">
            <div className="relative h-64 md:h-80 bg-gradient-to-br from-primary-400 to-accent-500">
              {scenepack.thumbnail_url ? <img src={scenepack.thumbnail_url} alt={scenepack.title} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center"><Film className="w-20 h-20 text-white/70" /></div>}
              {scenepack.trending && <div className="absolute top-4 right-4"><Badge variant="warning"><Crown className="w-3 h-3" /> Trending</Badge></div>}
            </div>
          </Card>

          <Card hover={false}>
            <div className="flex items-start justify-between gap-4 mb-4">
              <div>
                <h1 className="text-2xl md:text-3xl font-bold mb-1">{scenepack.title}</h1>
                <div className="flex items-center gap-2"><Badge>{scenepack.category}</Badge><span className="text-xs text-slate-400">{new Date(scenepack.created_at).toLocaleDateString()}</span></div>
              </div>
            </div>
            <p className="text-slate-600 dark:text-slate-300 mb-4">{scenepack.description || 'No description provided.'}</p>
            <div className="flex flex-wrap items-center gap-4 text-sm">
              <span className="flex items-center gap-1.5"><Download className="w-4 h-4 text-primary-500" /> {scenepack.downloads} downloads</span>
              <span className="flex items-center gap-1.5"><Eye className="w-4 h-4 text-primary-500" /> {scenepack.views} views</span>
              <span className="flex items-center gap-1.5"><Heart className="w-4 h-4 text-primary-500" /> {likeCount} likes</span>
              <span className="flex items-center gap-1.5"><Star className="w-4 h-4 text-warning-500 fill-warning-500" /> {avgRating.toFixed(1)} ({ratingCount})</span>
            </div>
          </Card>

          <Card hover={false}>
            <div className="flex flex-wrap gap-3">
              <button onClick={handleDownload} className="btn-primary flex items-center gap-2 flex-1 justify-center"><Download className="w-5 h-5" /> Download</button>
              <button onClick={toggleLike} className={`btn-secondary flex items-center gap-2 ${liked ? 'text-primary-500 border-primary-300' : ''}`}><Heart className={`w-5 h-5 ${liked ? 'fill-primary-500 text-primary-500' : ''}`} /> {likeCount}</button>
              {session && <button onClick={handleFavorite} className={`btn-secondary flex items-center gap-2 ${favorited ? 'text-primary-500 border-primary-300' : ''}`}><Bookmark className={`w-5 h-5 ${favorited ? 'fill-primary-500 text-primary-500' : ''}`} /></button>}
              <button onClick={handleShare} className="btn-secondary flex items-center gap-2"><Share2 className="w-5 h-5" /> {shareCopied ? 'Copied!' : 'Share'}</button>
            </div>
          </Card>

          {session && (
            <Card hover={false}>
              <h3 className="font-semibold mb-3">Rate this scenepack</h3>
              <div className="flex items-center gap-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button key={star} onClick={() => handleRate(star)} onMouseEnter={() => setHoverRating(star)} onMouseLeave={() => setHoverRating(0)} className="transition-transform hover:scale-110">
                    <Star className={`w-8 h-8 ${(hoverRating || userRating) >= star ? 'text-warning-500 fill-warning-500' : 'text-slate-300 dark:text-slate-600'}`} />
                  </button>
                ))}
                {userRating > 0 && <span className="ml-2 text-sm text-slate-500">Your rating: {userRating}/5</span>}
              </div>
            </Card>
          )}

          <Card hover={false}><CommentSection targetType="scenepack" targetId={id!} /></Card>
        </div>

        <div className="space-y-4">
          {creator && (
            <Card hover={false}>
              <h3 className="font-semibold mb-3 text-sm">Uploaded by</h3>
              <Link to={`/profile/${creator.id}`} className="flex items-center gap-3">
                <Avatar url={creator.avatar_url} username={creator.username} size={48} />
                <div><p className="font-semibold text-sm">{creator.username}</p><p className="text-xs text-slate-500">{creator.bio || 'No bio'}</p></div>
              </Link>
            </Card>
          )}
          <Card hover={false}>
            <h3 className="font-semibold mb-3 text-sm">Details</h3>
            <dl className="space-y-2 text-sm">
              <div className="flex justify-between"><dt className="text-slate-500">Category</dt><dd className="font-medium">{scenepack.category}</dd></div>
              <div className="flex justify-between"><dt className="text-slate-500">Downloads</dt><dd className="font-medium">{scenepack.downloads}</dd></div>
              <div className="flex justify-between"><dt className="text-slate-500">Views</dt><dd className="font-medium">{scenepack.views}</dd></div>
              <div className="flex justify-between"><dt className="text-slate-500">Rating</dt><dd className="font-medium">{avgRating.toFixed(1)}/5</dd></div>
              <div className="flex justify-between"><dt className="text-slate-500">Added</dt><dd className="font-medium">{new Date(scenepack.created_at).toLocaleDateString()}</dd></div>
            </dl>
          </Card>
        </div>
      </div>
    </div>
  );
}
