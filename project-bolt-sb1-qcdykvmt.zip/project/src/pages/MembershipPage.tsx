import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Crown, Check, CreditCard, Shield, Sparkles } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { Card, Spinner } from '@/components/ui';

export function MembershipPage() {
  const { session, profile } = useAuth();
  const navigate = useNavigate();
  const [subscribing, setSubscribing] = useState(false);
  const [hasActive, setHasActive] = useState(false);

  useEffect(() => {
    if (!session?.user) return;
    (async () => {
      const { data } = await supabase.from('subscriptions').select('*').eq('user_id', session.user.id).eq('status', 'active').maybeSingle();
      setHasActive(!!data);
    })();
  }, [session?.user]);

  const handleSubscribe = async () => {
    if (!session?.user) { navigate('/login'); return; }
    setSubscribing(true);
    const { error } = await supabase.from('subscriptions').insert({
      user_id: session.user.id, status: 'active',
      start_date: new Date().toISOString(),
      end_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      amount: 1.50, payment_method: 'paypal',
    });
    if (!error) setHasActive(true);
    setSubscribing(false);
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in">
      <div className="text-center mb-12">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-4"><Crown className="w-4 h-4 text-primary-500" /><span className="text-sm font-medium">Upload Membership</span></div>
        <h1 className="text-3xl md:text-5xl font-bold font-display mb-4">Unlock Upload Access</h1>
        <p className="text-slate-500 max-w-xl mx-auto">Subscribe for just €1.50/month and start uploading your own edits with custom quality and FPS settings.</p>
      </div>

      <Card hover={false} className="relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none"><div className="absolute top-0 right-0 w-64 h-64 bg-primary-300/20 rounded-full blur-3xl" /></div>
        <div className="relative">
          <div className="flex items-center justify-between mb-6">
            <div><h2 className="text-2xl font-bold">Upload Membership</h2><p className="text-sm text-slate-500">Monthly subscription</p></div>
            <div className="text-right"><p className="text-4xl font-bold gradient-text">€1.50</p><p className="text-sm text-slate-500">per month</p></div>
          </div>
          <div className="space-y-3 mb-6">
            {['Upload unlimited edits with quality & FPS settings', 'Access to member-only features', 'Priority listing in search', 'Upload membership badge on profile', 'Cancel anytime'].map((f) => (
              <div key={f} className="flex items-center gap-3"><div className="w-6 h-6 rounded-full bg-success-50 dark:bg-success-900/30 flex items-center justify-center flex-shrink-0"><Check className="w-4 h-4 text-success-500" /></div><span className="text-sm">{f}</span></div>
            ))}
          </div>
          {profile?.is_admin ? (
            <div className="p-4 rounded-xl bg-success-50 dark:bg-success-900/30 text-center"><Shield className="w-6 h-6 mx-auto mb-2 text-success-500" /><p className="font-semibold text-success-600 dark:text-success-400">You have free admin access</p><p className="text-xs text-slate-500 mt-1">Admins automatically receive all membership benefits at no cost.</p></div>
          ) : hasActive ? (
            <div className="p-4 rounded-xl bg-success-50 dark:bg-success-900/30 text-center"><Check className="w-6 h-6 mx-auto mb-2 text-success-500" /><p className="font-semibold text-success-600 dark:text-success-400">Active Subscription</p><p className="text-xs text-slate-500 mt-1">You have an active upload membership.</p><button onClick={() => navigate('/dashboard')} className="btn-secondary mt-3 text-sm">Go to Dashboard</button></div>
          ) : (
            <button onClick={handleSubscribe} disabled={subscribing} className="btn-primary w-full flex items-center justify-center gap-2 disabled:opacity-50">{subscribing ? <Spinner className="w-5 h-5" /> : <><CreditCard className="w-5 h-5" /> Subscribe with PayPal</>}</button>
          )}
        </div>
      </Card>

      <div className="grid sm:grid-cols-3 gap-4 mt-6">
        <Card className="text-center"><Shield className="w-8 h-8 mx-auto mb-2 text-primary-500" /><h4 className="font-semibold text-sm">Secure Payment</h4><p className="text-xs text-slate-500 mt-1">Processed securely via PayPal</p></Card>
        <Card className="text-center"><Sparkles className="w-8 h-8 mx-auto mb-2 text-primary-500" /><h4 className="font-semibold text-sm">Instant Access</h4><p className="text-xs text-slate-500 mt-1">Upload immediately after payment</p></Card>
        <Card className="text-center"><Crown className="w-8 h-8 mx-auto mb-2 text-primary-500" /><h4 className="font-semibold text-sm">Cancel Anytime</h4><p className="text-xs text-slate-500 mt-1">No long-term commitment</p></Card>
      </div>
    </div>
  );
}
