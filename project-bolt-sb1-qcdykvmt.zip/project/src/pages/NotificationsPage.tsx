import { useEffect, useState } from 'react';
import { Bell, Heart, MessageCircle, UserPlus, Reply, Info, Check } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { Card, EmptyState } from '@/components/ui';
import type { Notification } from '@/types';

const iconMap: Record<string, typeof Heart> = { like: Heart, comment: MessageCircle, follow: UserPlus, reply: Reply, system: Info };

export function NotificationsPage() {
  const { session } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchNotifications = async () => {
    if (!session?.user) return;
    const { data } = await supabase.from('notifications').select('*').eq('user_id', session.user.id).order('created_at', { ascending: false }).limit(50);
    setNotifications(data ?? []);
    setLoading(false);
  };

  useEffect(() => { fetchNotifications(); }, [session?.user]);

  const markAllRead = async () => {
    if (!session?.user) return;
    await supabase.from('notifications').update({ read: true }).eq('user_id', session.user.id).eq('read', false);
    fetchNotifications();
  };

  const markRead = async (id: string) => {
    await supabase.from('notifications').update({ read: true }).eq('id', id);
    fetchNotifications();
  };

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold font-display mb-2 flex items-center gap-2"><Bell className="w-8 h-8 text-primary-500" /> Notifications</h1>
          <p className="text-slate-500">{unreadCount} unread</p>
        </div>
        {unreadCount > 0 && <button onClick={markAllRead} className="btn-secondary text-sm flex items-center gap-2"><Check className="w-4 h-4" /> Mark all read</button>}
      </div>

      {loading ? (
        <div className="space-y-3">{[...Array(5)].map((_, i) => <div key={i} className="h-16 rounded-xl skeleton" />)}</div>
      ) : notifications.length === 0 ? (
        <EmptyState icon={<Bell className="w-8 h-8" />} title="No notifications" message="You're all caught up!" />
      ) : (
        <div className="space-y-2">
          {notifications.map((n) => {
            const Icon = iconMap[n.type] || Info;
            return (
              <Card key={n.id} className={`!p-4 ${!n.read ? 'border-primary-300/50' : ''}`} hover={false}>
                <div className="flex items-start gap-3">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${n.type === 'like' ? 'bg-error-50 dark:bg-error-900/30 text-error-500' : n.type === 'comment' ? 'bg-primary-50 dark:bg-primary-900/30 text-primary-500' : n.type === 'follow' ? 'bg-accent-50 dark:bg-accent-900/30 text-accent-500' : 'bg-slate-100 dark:bg-slate-800 text-slate-500'}`}><Icon className="w-5 h-5" /></div>
                  <div className="flex-1 min-w-0"><p className="text-sm">{n.message}</p><p className="text-xs text-slate-400 mt-0.5">{new Date(n.created_at).toLocaleString()}</p></div>
                  {!n.read && <button onClick={() => markRead(n.id)} className="w-2 h-2 rounded-full bg-primary-500 mt-2 flex-shrink-0" title="Mark as read" />}
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
