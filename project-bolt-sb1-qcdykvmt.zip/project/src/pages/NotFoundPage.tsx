import { Link } from 'react-router-dom';
import { Home, Compass } from 'lucide-react';

export function NotFoundPage() {
  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4 animate-fade-in">
      <div className="text-center">
        <div className="w-20 h-20 rounded-2xl glass flex items-center justify-center mx-auto mb-6 animate-float"><Compass className="w-10 h-10 text-primary-500" /></div>
        <h1 className="text-6xl font-bold font-display gradient-text mb-2">404</h1>
        <p className="text-xl font-semibold mb-2">Page not found</p>
        <p className="text-slate-500 mb-8">The page you're looking for doesn't exist or has been moved.</p>
        <Link to="/" className="btn-primary inline-flex items-center gap-2"><Home className="w-5 h-5" /> Back to Home</Link>
      </div>
    </div>
  );
}
