import { useEffect, useState } from 'react';
import {
  Shield, Film, GraduationCap, Users, Download, Heart, MessageCircle,
  Star, TrendingUp, Crown, Newspaper, Megaphone, Plus, Trash2, Edit3,
  UserCog, Ban, CheckCircle2, X, Send,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Card, StatCard, Badge, Spinner, Modal, ConfirmDialog } from '@/components/ui';
import { Avatar } from '@/components/Avatar';
import type { Profile, Scenepack, Tutorial, Order, Announcement, News } from '@/types';

type Tab = 'overview' | 'scenepacks' | 'tutorials' | 'requests' | 'users' | 'orders' | 'content';

export function AdminPage() {
  const [tab, setTab] = useState<Tab>('overview');
  const [stats, setStats] = useState({ members: 0, scenepacks: 0, tutorials: 0, downloads: 0, likes: 0, comments: 0, ratings: 0, orders: 0 });
  const [scenepacks, setScenepacks] = useState<Scenepack[]>([]);
  const [tutorials, setTutorials] = useState<Tutorial[]>([]);
  const [users, setUsers] = useState<Profile[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [news, setNews] = useState<News[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [addType, setAddType] = useState<'scenepack' | 'tutorial' | 'announcement' | 'news'>('scenepack');
  const [confirmDelete, setConfirmDelete] = useState<{ type: string; id: string } | null>(null);

  const fetchData = async () => {
    setLoading(true);
    const [sp, tut, usr, ord, ann, nw,
      { count: m }, { count: spCount }, { count: tutCount },
      { count: likeCount }, { count: cmtCount }, { count: ratCount }, { count: ordCount },
    ] = await Promise.all([
      supabase.from('scenepacks').select('*').order('created_at', { ascending: false }),
      supabase.from('tutorials').select('*').order('created_at', { ascending: false }),
      supabase.from('profiles').select('*').order('created_at', { ascending: false }),
      supabase.from('orders').select('*').order('created_at', { ascending: false }),
      supabase.from('announcements').select('*').order('created_at', { ascending: false }),
      supabase.from('news').select('*').order('created_at', { ascending: false }),
      supabase.from('profiles').select('*', { count: 'exact', head: true }),
      supabase.from('scenepacks').select('*', { count: 'exact', head: true }),
      supabase.from('tutorials').select('*', { count: 'exact', head: true }),
      supabase.from('likes').select('*', { count: 'exact', head: true }),
      supabase.from('comments').select('*', { count: 'exact', head: true }),
      supabase.from('ratings').select('*', { count: 'exact', head: true }),
      supabase.from('orders').select('*', { count: 'exact', head: true }),
    ]);

    setScenepacks(sp.data ?? []);
    setTutorials(tut.data ?? []);
    setUsers(usr.data ?? []);
    setOrders(ord.data ?? []);
    setAnnouncements(ann.data ?? []);
    setNews(nw.data ?? []);
    const dlTotal = (sp.data ?? []).reduce((s, p) => s + (p as Scenepack).downloads, 0);
    setStats({ members: m ?? 0, scenepacks: spCount ?? 0, tutorials: tutCount ?? 0, downloads: dlTotal, likes: likeCount ?? 0, comments: cmtCount ?? 0, ratings: ratCount ?? 0, orders: ordCount ?? 0 });
    setLoading(false);
  };

  useEffect(() => { fetchData(); }, []);

  const handleDelete = async () => {
    if (!confirmDelete) return;
    const { type, id } = confirmDelete;
    if (type === 'scenepack') await supabase.from('scenepacks').delete().eq('id', id);
    if (type === 'tutorial') await supabase.from('tutorials').delete().eq('id', id);
    if (type === 'announcement') await supabase.from('announcements').delete().eq('id', id);
    if (type === 'news') await supabase.from('news').delete().eq('id', id);
    setConfirmDelete(null);
    fetchData();
  };

  const toggleAdmin = async (user: Profile) => {
    await supabase.from('profiles').update({ is_admin: !user.is_admin }).eq('id', user.id);
    fetchData();
  };

  const tabs: { key: Tab; label: string; icon: typeof Shield }[] = [
    { key: 'overview', label: 'Overview', icon: TrendingUp },
    { key: 'scenepacks', label: 'Scenepacks', icon: Film },
    { key: 'tutorials', label: 'Tutorials', icon: GraduationCap },
    { key: 'users', label: 'Users', icon: Users },
    { key: 'orders', label: 'Orders', icon: Crown },
    { key: 'content', label: 'Content', icon: Newspaper },
  ];

  if (loading) return <div className="min-h-[60vh] flex items-center justify-center"><Spinner className="w-16 h-16" /></div>;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in">
      <div className="flex items-center gap-2 mb-8">
        <Shield className="w-8 h-8 text-primary-500" />
        <h1 className="text-3xl font-bold font-display">Admin Dashboard</h1>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-6 overflow-x-auto no-scrollbar">
        {tabs.map(({ key, label, icon: Icon }) => (
          <button
            key={key}
            onClick={() => setTab(key)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${
              tab === key ? 'bg-primary-500 text-white' : 'glass hover:bg-primary-50 dark:hover:bg-primary-900/20'
            }`}
          >
            <Icon className="w-4 h-4" /> {label}
          </button>
        ))}
      </div>

      {/* Overview */}
      {tab === 'overview' && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <StatCard icon={<Users className="w-6 h-6" />} label="Total Members" value={stats.members} color="primary" />
          <StatCard icon={<Film className="w-6 h-6" />} label="Scenepacks" value={stats.scenepacks} color="accent" />
          <StatCard icon={<GraduationCap className="w-6 h-6" />} label="Tutorials" value={stats.tutorials} color="success" />
          <StatCard icon={<Download className="w-6 h-6" />} label="Downloads" value={stats.downloads} color="warning" />
          <StatCard icon={<Heart className="w-6 h-6" />} label="Total Likes" value={stats.likes} color="error" />
          <StatCard icon={<MessageCircle className="w-6 h-6" />} label="Comments" value={stats.comments} color="primary" />
          <StatCard icon={<Star className="w-6 h-6" />} label="Reviews" value={stats.ratings} color="warning" />
          <StatCard icon={<Crown className="w-6 h-6" />} label="Orders" value={stats.orders} color="success" />
        </div>
      )}

      {/* Scenepacks management */}
      {tab === 'scenepacks' && (
        <div>
          <div className="flex justify-between mb-4">
            <h2 className="text-xl font-bold">Manage Scenepacks</h2>
            <button onClick={() => { setAddType('scenepack'); setShowAdd(true); }} className="btn-primary text-sm flex items-center gap-2">
              <Plus className="w-4 h-4" /> Add Scenepack
            </button>
          </div>
          <div className="space-y-2">
            {scenepacks.map((sp) => (
              <Card key={sp.id} className="!p-3 flex items-center gap-3" hover={false}>
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary-400 to-accent-500 flex items-center justify-center flex-shrink-0">
                  <Film className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-semibold text-sm truncate">{sp.title}</h4>
                  <p className="text-xs text-slate-500">{sp.category} · {sp.downloads} downloads</p>
                </div>
                {sp.trending && <Badge variant="warning">Trending</Badge>}
                <button onClick={() => setConfirmDelete({ type: 'scenepack', id: sp.id })} className="p-2 rounded-lg text-slate-400 hover:text-error-500 hover:bg-error-50 dark:hover:bg-error-900/20 transition-all">
                  <Trash2 className="w-4 h-4" />
                </button>
              </Card>
            ))}
            {scenepacks.length === 0 && <Card hover={false} className="text-center py-8 text-slate-500 text-sm">No scenepacks yet.</Card>}
          </div>
        </div>
      )}

      {/* Tutorials management */}
      {tab === 'tutorials' && (
        <div>
          <div className="flex justify-between mb-4">
            <h2 className="text-xl font-bold">Manage Tutorials</h2>
            <button onClick={() => { setAddType('tutorial'); setShowAdd(true); }} className="btn-primary text-sm flex items-center gap-2">
              <Plus className="w-4 h-4" /> Add Tutorial
            </button>
          </div>
          <div className="space-y-2">
            {tutorials.map((t) => (
              <Card key={t.id} className="!p-3 flex items-center gap-3" hover={false}>
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary-400 to-accent-500 flex items-center justify-center flex-shrink-0">
                  <GraduationCap className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-semibold text-sm truncate">{t.title}</h4>
                  <p className="text-xs text-slate-500">{t.views} views</p>
                </div>
                <button onClick={() => setConfirmDelete({ type: 'tutorial', id: t.id })} className="p-2 rounded-lg text-slate-400 hover:text-error-500 hover:bg-error-50 dark:hover:bg-error-900/20 transition-all">
                  <Trash2 className="w-4 h-4" />
                </button>
              </Card>
            ))}
            {tutorials.length === 0 && <Card hover={false} className="text-center py-8 text-slate-500 text-sm">No tutorials yet.</Card>}
          </div>
        </div>
      )}

      {/* Users management */}
      {tab === 'users' && (
        <div>
          <h2 className="text-xl font-bold mb-4">Manage Users</h2>
          <div className="space-y-2">
            {users.map((u) => (
              <Card key={u.id} className="!p-3 flex items-center gap-3" hover={false}>
                <Avatar url={u.avatar_url} username={u.username} size={40} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h4 className="font-semibold text-sm truncate">{u.username}</h4>
                    {u.is_admin && <Badge variant="warning"><Crown className="w-3 h-3" /> Admin</Badge>}
                  </div>
                  <p className="text-xs text-slate-500">Joined {new Date(u.created_at).toLocaleDateString()}</p>
                </div>
                <button onClick={() => toggleAdmin(u)} className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${u.is_admin ? 'glass text-slate-600 dark:text-slate-300' : 'btn-primary text-sm'}`}>
                  {u.is_admin ? 'Remove Admin' : 'Make Admin'}
                </button>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Orders */}
      {tab === 'orders' && (
        <div>
          <h2 className="text-xl font-bold mb-4">Website Orders</h2>
          <div className="space-y-2">
            {orders.map((o) => (
              <Card key={o.id} className="!p-3" hover={false}>
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-semibold text-sm">{o.customer_name}</h4>
                    <p className="text-xs text-slate-500">{o.customer_email} · {o.service_tier} (€{o.price})</p>
                  </div>
                  <Badge variant={o.status === 'completed' ? 'success' : o.status === 'in_progress' ? 'warning' : o.status === 'cancelled' ? 'error' : 'primary'}>
                    {o.status.replace('_', ' ')}
                  </Badge>
                </div>
                {o.requirements && <p className="text-xs text-slate-500 mt-2">{o.requirements}</p>}
              </Card>
            ))}
            {orders.length === 0 && <Card hover={false} className="text-center py-8 text-slate-500 text-sm">No orders yet.</Card>}
          </div>
        </div>
      )}

      {/* Content (announcements + news) */}
      {tab === 'content' && (
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <div className="flex justify-between mb-4">
              <h2 className="text-xl font-bold flex items-center gap-2"><Megaphone className="w-5 h-5 text-primary-500" /> Announcements</h2>
              <button onClick={() => { setAddType('announcement'); setShowAdd(true); }} className="btn-primary text-sm flex items-center gap-2">
                <Plus className="w-4 h-4" /> Add
              </button>
            </div>
            <div className="space-y-2">
              {announcements.map((a) => (
                <Card key={a.id} className="!p-3" hover={false}>
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <h4 className="font-semibold text-sm">{a.title}</h4>
                      <p className="text-xs text-slate-500 line-clamp-2">{a.content}</p>
                    </div>
                    <button onClick={() => setConfirmDelete({ type: 'announcement', id: a.id })} className="p-1.5 rounded text-slate-400 hover:text-error-500">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </Card>
              ))}
              {announcements.length === 0 && <Card hover={false} className="text-center py-6 text-slate-500 text-sm">No announcements.</Card>}
            </div>
          </div>
          <div>
            <div className="flex justify-between mb-4">
              <h2 className="text-xl font-bold flex items-center gap-2"><Newspaper className="w-5 h-5 text-primary-500" /> News</h2>
              <button onClick={() => { setAddType('news'); setShowAdd(true); }} className="btn-primary text-sm flex items-center gap-2">
                <Plus className="w-4 h-4" /> Add
              </button>
            </div>
            <div className="space-y-2">
              {news.map((n) => (
                <Card key={n.id} className="!p-3" hover={false}>
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <h4 className="font-semibold text-sm">{n.title}</h4>
                      <p className="text-xs text-slate-500 line-clamp-2">{n.content}</p>
                    </div>
                    <button onClick={() => setConfirmDelete({ type: 'news', id: n.id })} className="p-1.5 rounded text-slate-400 hover:text-error-500">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </Card>
              ))}
              {news.length === 0 && <Card hover={false} className="text-center py-6 text-slate-500 text-sm">No news articles.</Card>}
            </div>
          </div>
        </div>
      )}

      {/* Add modal */}
      <AddContentModal
        isOpen={showAdd}
        onClose={() => setShowAdd(false)}
        type={addType}
        onSaved={() => { setShowAdd(false); fetchData(); }}
      />

      <ConfirmDialog
        isOpen={!!confirmDelete}
        onClose={() => setConfirmDelete(null)}
        onConfirm={handleDelete}
        title="Delete Item"
        message="Are you sure you want to delete this item? This action cannot be undone."
      />
    </div>
  );
}

function AddContentModal({ isOpen, onClose, type, onSaved }: { isOpen: boolean; onClose: () => void; type: string; onSaved: () => void }) {
  const [form, setForm] = useState({ title: '', description: '', category: 'General', thumbnail_url: '', download_url: '', video_url: '', content: '', image_url: '' });
  const [saving, setSaving] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    if (type === 'scenepack') {
      await supabase.from('scenepacks').insert({ title: form.title, description: form.description, category: form.category, thumbnail_url: form.thumbnail_url || null, download_url: form.download_url || null });
    } else if (type === 'tutorial') {
      await supabase.from('tutorials').insert({ title: form.title, description: form.description, video_url: form.video_url || null, thumbnail_url: form.thumbnail_url || null });
    } else if (type === 'announcement') {
      await supabase.from('announcements').insert({ title: form.title, content: form.content });
    } else if (type === 'news') {
      await supabase.from('news').insert({ title: form.title, content: form.content, image_url: form.image_url || null });
    }
    setSaving(false);
    setForm({ title: '', description: '', category: 'General', thumbnail_url: '', download_url: '', video_url: '', content: '', image_url: '' });
    onSaved();
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`Add ${type}`}>
      <form onSubmit={handleSubmit} className="space-y-3">
        <div>
          <label className="block text-sm font-medium mb-1">Title</label>
          <input type="text" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="input-field" required />
        </div>
        {type === 'scenepack' && (
          <>
            <div>
              <label className="block text-sm font-medium mb-1">Category</label>
              <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className="input-field">
                {['General', 'Cinematic', 'VFX', 'Transitions', 'Color Grading', 'Audio', '3D', 'Motion Graphics', 'Intro', 'Outro'].map((c) => <option key={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Thumbnail URL</label>
              <input type="url" value={form.thumbnail_url} onChange={(e) => setForm({ ...form, thumbnail_url: e.target.value })} className="input-field" placeholder="https://..." />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Download URL</label>
              <input type="url" value={form.download_url} onChange={(e) => setForm({ ...form, download_url: e.target.value })} className="input-field" placeholder="https://..." />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Description</label>
              <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="input-field resize-none" rows={3} />
            </div>
          </>
        )}
        {type === 'tutorial' && (
          <>
            <div>
              <label className="block text-sm font-medium mb-1">Video URL</label>
              <input type="url" value={form.video_url} onChange={(e) => setForm({ ...form, video_url: e.target.value })} className="input-field" placeholder="https://..." />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Thumbnail URL</label>
              <input type="url" value={form.thumbnail_url} onChange={(e) => setForm({ ...form, thumbnail_url: e.target.value })} className="input-field" placeholder="https://..." />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Description</label>
              <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="input-field resize-none" rows={3} />
            </div>
          </>
        )}
        {(type === 'announcement' || type === 'news') && (
          <div>
            <label className="block text-sm font-medium mb-1">Content</label>
            <textarea value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} className="input-field resize-none" rows={4} required />
          </div>
        )}
        {type === 'news' && (
          <div>
            <label className="block text-sm font-medium mb-1">Image URL</label>
            <input type="url" value={form.image_url} onChange={(e) => setForm({ ...form, image_url: e.target.value })} className="input-field" placeholder="https://..." />
          </div>
        )}
        <button type="submit" disabled={saving} className="btn-primary w-full flex items-center justify-center gap-2 disabled:opacity-50">
          <Send className="w-4 h-4" /> {saving ? 'Saving...' : 'Save'}
        </button>
      </form>
    </Modal>
  );
}
