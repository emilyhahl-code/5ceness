import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { User, Heart, Film, Crown, Calendar, Edit3, UserPlus, UserCheck } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { Card, Badge, Spinner, EmptyState } from '@/components/ui';
import { Avatar } from '@/components/Avatar';
import type { Profile, Scenepack } from '@/types';

export function ProfilePage() {
  const { id } = useParams<{ id: string }>();
  const { session } = useAuth();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [scenepacks, setScenepacks] = useState<Scenepack[]>([]);
  const [favorites, setFavorites] = useState<Scenepack[]>([]);
  const [followers, setFollowers] = useState(0);
  const [following, setFollowing] = useState(0);
  const [isFollowing, setIsFollowing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<'packs' | 'favorites' | 'about'>('packs');

  useEffect(() => {
    if (!id) return;
    (async () => {
      const { data: p } = await supabase.from('profiles').select('*').eq('id', id).maybeSingle();
      if (!p) { setLoading(false); return; }
      setProfile(p as Profile);
      const { data: packs } = await supabase.from('scenepacks').select('*').eq('creator_id', id).order('created_at', { ascending: false });
      setScenepacks(packs ?? []);
      const { data: favs } = await supabase.from('favorites').select('scenepacks:scenepacks(*)').eq('user_id', id);
      setFavorites((favs ?? []).map((f: { scenepacks: Scenepack[] }) => f.scenepacks?.[0]).filter(Boolean));
      const { count: fc } = await supabase.from('follows').select('*', { count: 'exact', head: true }).eq('following_id', id);
      setFollowers(fc ?? 0);
      const { count: fg } = await supabase.from('follows').select('*', { count: 'exact', head: true }).eq('follower_id', id);
      setFollowing(fg ?? 0);
      if (session?.user && session.user.id !== id) {
        const { data: fol } = await supabase.from('follows').select('id').eq('follower_id', session.user.id).eq('following_id', id).maybeSingle();
        setIsFollowing(!!fol);
      }
      setLoading(false);
    })();
  }, [id, session?.user]);

  const handleFollow = async () => {
    if (!session?.user || !id) return;
    if (isFollowing) {
      await supabase.from('follows').delete().eq('follower_id', session.user.id).eq('following_id', id);
      setIsFollowing(false); setFollowers((f) => Math.max(0, f - 1));
    } else {
      await supabase.from('follows').insert({ follower_id: session.user.id, following_id: id });
      setIsFollowing(true); setFollowers((f) => f + 1);
    }
  };

  if (loading) return <div className="min-h-[60vh] flex items-center justify-center"><Spinner className="w-16 h-16" /></div>;
  if (!profile) return <EmptyState icon={<User className="w-8 h-8" />} title="User not found" message="This profile may not exist." />;

  const isOwn = session?.user?.id === id;

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in">
      <div className="relative h-40 md:h-56 rounded-2xl overflow-hidden glass-card mb-16">
        {profile.banner_url ? <img src={profile.banner_url} alt="Banner" className="w-full h-full object-cover" /> : <div className="w-full h-full bg-gradient-to-br from-primary-300/30 to-accent-400/30" />}
        <div className="absolute -bottom-12 left-6"><Avatar url={profile.avatar_url} username={profile.username} size={96} /></div>
      </div>
      <div className="flex items-start justify-between mb-8">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h1 className="text-2xl font-bold">{profile.username}</h1>
            {profile.is_admin && <Badge variant="warning"><Crown className="w-3 h-3" /> Admin</Badge>}
          </div>
          {profile.full_name && <p className="text-sm text-slate-500">{profile.full_name}</p>}
          {profile.bio && <p className="text-sm text-slate-500 mt-2 max-w-md">{profile.bio}</p>}
          <div className="flex items-center gap-4 mt-3 text-sm text-slate-500">
            <span className="flex items-center gap-1"><Calendar className="w-4 h-4" /> Joined {new Date(profile.created_at).toLocaleDateString()}</span>
            <span><strong className="text-slate-700 dark:text-slate-200">{followers}</strong> followers</span>
            <span><strong className="text-slate-700 dark:text-slate-200">{following}</strong> following</span>
          </div>
        </div>
        {isOwn ? (
          <Link to="/customize" className="btn-secondary flex items-center gap-2 text-sm"><Edit3 className="w-4 h-4" /> Edit Profile</Link>
        ) : session?.user ? (
          <button onClick={handleFollow} className={isFollowing ? 'btn-secondary flex items-center gap-2 text-sm' : 'btn-primary flex items-center gap-2 text-sm'}>
            {isFollowing ? <><UserCheck className="w-4 h-4" /> Following</> : <><UserPlus className="w-4 h-4" /> Follow</>}
          </button>
        ) : null}
      </div>

      <div className="flex gap-2 mb-6">
        {([['packs', 'Scenepacks'], ['favorites', 'Favorites'], ['about', 'About']] as const).map(([key, label]) => (
          <button key={key} onClick={() => setTab(key)} className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${tab === key ? 'bg-primary-500 text-white' : 'glass hover:bg-primary-50 dark:hover:bg-primary-900/20'}`}>{label}</button>
        ))}
      </div>

      {tab === 'packs' && (scenepacks.length === 0 ? (
        <EmptyState icon={<Film className="w-8 h-8" />} title="No scenepacks" message="This user hasn't uploaded any scenepacks yet." />
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {scenepacks.map((sp) => (
            <Link key={sp.id} to={`/scenepacks/${sp.id}`}>
              <Card className="!p-0 overflow-hidden h-full">
                <div className="h-32 bg-gradient-to-br from-primary-400 to-accent-500 flex items-center justify-center">
                  {sp.thumbnail_url ? <img src={sp.thumbnail_url} alt={sp.title} className="w-full h-full object-cover" /> : <Film className="w-8 h-8 text-white/70" />}
                </div>
                <div className="p-3"><h4 className="font-semibold text-sm truncate">{sp.title}</h4><p className="text-xs text-slate-500">{sp.downloads} downloads</p></div>
              </Card>
            </Link>
          ))}
        </div>
      ))}

      {tab === 'favorites' && (favorites.length === 0 ? (
        <EmptyState icon={<Heart className="w-8 h-8" />} title="No favorites" message="This user hasn't favorited any scenepacks." />
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {favorites.map((sp) => (
            <Link key={sp.id} to={`/scenepacks/${sp.id}`}>
              <Card className="!p-0 overflow-hidden h-full">
                <div className="h-32 bg-gradient-to-br from-primary-400 to-accent-500 flex items-center justify-center">
                  {sp.thumbnail_url ? <img src={sp.thumbnail_url} alt={sp.title} className="w-full h-full object-cover" /> : <Film className="w-8 h-8 text-white/70" />}
                </div>
                <div className="p-3"><h4 className="font-semibold text-sm truncate">{sp.title}</h4><p className="text-xs text-slate-500">{sp.downloads} downloads</p></div>
              </Card>
            </Link>
          ))}
        </div>
      ))}

      {tab === 'about' && (
        <Card hover={false}>
          <dl className="space-y-3 text-sm">
            <div className="flex justify-between"><dt className="text-slate-500">Username</dt><dd className="font-medium">{profile.username}</dd></div>
            {profile.full_name && <div className="flex justify-between"><dt className="text-slate-500">Full Name</dt><dd className="font-medium">{profile.full_name}</dd></div>}
            <div className="flex justify-between"><dt className="text-slate-500">Joined</dt><dd className="font-medium">{new Date(profile.created_at).toLocaleDateString()}</dd></div>
            <div className="flex justify-between"><dt className="text-slate-500">Theme</dt><dd className="font-medium capitalize">{profile.background_theme}</dd></div>
            <div className="flex justify-between"><dt className="text-slate-500">Accent</dt><dd className="font-medium capitalize">{profile.accent_color}</dd></div>
          </dl>
          {profile.bio && <p className="mt-4 pt-4 border-t border-slate-200/50 dark:border-slate-700/50 text-sm text-slate-600 dark:text-slate-300">{profile.bio}</p>}
        </Card>
      )}
    </div>
  );
}
