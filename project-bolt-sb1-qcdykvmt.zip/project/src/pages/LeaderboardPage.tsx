import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Trophy, Download, Heart, Star, Crown } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Card, Badge, EmptyState } from '@/components/ui';
import { Avatar } from '@/components/Avatar';
import type { Profile } from '@/types';

type LeaderboardEntry = { profile: Profile; downloads: number; likes: number; ratings: number; total: number };

export function LeaderboardPage() {
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<'downloads' | 'likes' | 'ratings'>('downloads');

  useEffect(() => {
    (async () => {
      const { data: profiles } = await supabase.from('profiles').select('*').limit(50);
      if (!profiles) { setLoading(false); return; }
      const entries: LeaderboardEntry[] = [];
      for (const p of profiles as Profile[]) {
        const { data: packs } = await supabase.from('scenepacks').select('downloads').eq('creator_id', p.id);
        const downloads = (packs ?? []).reduce((s, sp) => s + (sp as { downloads: number }).downloads, 0);
        const { count: likes } = await supabase.from('likes').select('*', { count: 'exact', head: true }).eq('user_id', p.id);
        const { count: ratings } = await supabase.from('ratings').select('*', { count: 'exact', head: true }).eq('user_id', p.id);
        entries.push({ profile: p, downloads, likes: likes ?? 0, ratings: ratings ?? 0, total: downloads + (likes ?? 0) + (ratings ?? 0) });
      }
      setEntries(entries);
      setLoading(false);
    })();
  }, []);

  const sorted = [...entries].sort((a, b) => tab === 'downloads' ? b.downloads - a.downloads : tab === 'likes' ? b.likes - a.likes : b.ratings - a.ratings);
  const getMedal = (i: number) => i === 0 ? 'text-warning-500' : i === 1 ? 'text-slate-400' : i === 2 ? 'text-amber-700' : 'text-slate-300';

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in">
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold font-display mb-2 flex items-center gap-2"><Trophy className="w-8 h-8 text-primary-500" /> Leaderboard</h1>
        <p className="text-slate-500">Top creators in the 5CENES community.</p>
      </div>

      <div className="flex gap-2 mb-6">
        {([['downloads', 'Downloads'], ['likes', 'Likes'], ['ratings', 'Ratings']] as const).map(([key, label]) => (
          <button key={key} onClick={() => setTab(key)} className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${tab === key ? 'bg-primary-500 text-white' : 'glass hover:bg-primary-50 dark:hover:bg-primary-900/20'}`}>{label}</button>
        ))}
      </div>

      {loading ? (
        <div className="space-y-3">{[...Array(5)].map((_, i) => <div key={i} className="h-20 rounded-xl skeleton" />)}</div>
      ) : sorted.length === 0 || sorted.every((e) => e.total === 0) ? (
        <EmptyState icon={<Trophy className="w-8 h-8" />} title="No leaderboard data" message="Start creating and uploading to climb the ranks!" />
      ) : (
        <div className="space-y-3">
          {sorted.slice(0, 20).map((entry, i) => (
            <Card key={entry.profile.id} className="!p-4" hover={false}>
              <div className="flex items-center gap-4">
                <div className={`text-2xl font-bold ${getMedal(i)} w-8 text-center`}>{i < 3 ? <Trophy className={`w-6 h-6 mx-auto ${getMedal(i)}`} /> : i + 1}</div>
                <Link to={`/profile/${entry.profile.id}`}><Avatar url={entry.profile.avatar_url} username={entry.profile.username} size={48} /></Link>
                <div className="flex-1 min-w-0">
                  <Link to={`/profile/${entry.profile.id}`} className="flex items-center gap-2">
                    <h4 className="font-semibold truncate">{entry.profile.username}</h4>
                    {entry.profile.is_admin && <Badge variant="warning"><Crown className="w-3 h-3" /></Badge>}
                  </Link>
                  <div className="flex items-center gap-4 text-xs text-slate-500 mt-1">
                    <span className="flex items-center gap-1"><Download className="w-3 h-3" /> {entry.downloads}</span>
                    <span className="flex items-center gap-1"><Heart className="w-3 h-3" /> {entry.likes}</span>
                    <span className="flex items-center gap-1"><Star className="w-3 h-3" /> {entry.ratings}</span>
                  </div>
                </div>
                <div className="text-right"><p className="text-2xl font-bold gradient-text">{tab === 'downloads' ? entry.downloads : tab === 'likes' ? entry.likes : entry.ratings}</p><p className="text-xs text-slate-500">{tab}</p></div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
