import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Crown, Check, X, Clock, Settings, Heart, Film, Star, MessageCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { Card, StatCard, Spinner } from '@/components/ui';
import type { Subscription } from '@/types';

export function DashboardPage() {
  const { session, profile } = useAuth();
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [favorites, setFavorites] = useState(0);
  const [ratings, setRatings] = useState(0);
  const [comments, setComments] = useState(0);
  const [likedCount, setLikedCount] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!session?.user) return;
    (async () => {
      const { data: sub } = await supabase.from('subscriptions').select('*').eq('user_id', session.user.id).eq('status', 'active').order('end_date', { ascending: false }).maybeSingle();
      setSubscription(sub as Subscription | null);
      const { count: favCount } = await supabase.from('favorites').select('*', { count: 'exact', head: true }).eq('user_id', session.user.id);
      setFavorites(favCount ?? 0);
      const { count: ratCount } = await supabase.from('ratings').select('*', { count: 'exact', head: true }).eq('user_id', session.user.id);
      setRatings(ratCount ?? 0);
      const { count: cmtCount } = await supabase.from('comments').select('*', { count: 'exact', head: true }).eq('user_id', session.user.id);
      setComments(cmtCount ?? 0);
      const { count: likeCount } = await supabase.from('likes').select('*', { count: 'exact', head: true }).eq('user_id', session.user.id);
      setLikedCount(likeCount ?? 0);
      setLoading(false);
    })();
  }, [session?.user]);

  if (loading) return <div className="min-h-[60vh] flex items-center justify-center"><Spinner className="w-16 h-16" /></div>;

  const daysLeft = subscription ? Math.ceil((new Date(subscription.end_date).getTime() - Date.now()) / (1000 * 60 * 60 * 24)) : 0;

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in">
      <div className="mb-8">
        <h1 className="text-3xl font-bold font-display mb-2">Member Dashboard</h1>
        <p className="text-slate-500">Welcome back, {profile?.username}!</p>
      </div>

      <Card hover={false} className="mb-6">
        <div className="flex items-center gap-4 mb-4">
          <div className={`w-14 h-14 rounded-xl flex items-center justify-center ${subscription ? 'bg-success-50 dark:bg-success-900/30' : 'bg-slate-100 dark:bg-slate-800'}`}>
            <Crown className={`w-7 h-7 ${subscription ? 'text-success-500' : 'text-slate-400'}`} />
          </div>
          <div className="flex-1">
            <h3 className="font-bold text-lg">Edit Upload Membership</h3>
            {profile?.is_admin ? (
              <p className="text-sm text-success-500 font-medium">Active (Admin — Free Access)</p>
            ) : subscription ? (
              <div>
                <p className="text-sm text-success-500 font-medium flex items-center gap-1"><Check className="w-4 h-4" /> Active</p>
                <p className="text-xs text-slate-500 flex items-center gap-1 mt-0.5"><Clock className="w-3 h-3" /> {daysLeft} days remaining · expires {new Date(subscription.end_date).toLocaleDateString()}</p>
              </div>
            ) : (
              <div>
                <p className="text-sm text-slate-500 flex items-center gap-1"><X className="w-4 h-4" /> Not subscribed</p>
                <Link to="/membership" className="text-sm text-primary-500 font-semibold hover:underline">Subscribe for €1.50/month</Link>
              </div>
            )}
          </div>
        </div>
        {subscription && !profile?.is_admin && (
          <div className="pt-4 border-t border-slate-200/50 dark:border-slate-700/50">
            <div className="flex justify-between text-xs text-slate-500 mb-1"><span>Subscription period</span><span>{daysLeft}/30 days</span></div>
            <div className="h-2 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
              <div className="h-full bg-gradient-to-r from-primary-400 to-accent-500 rounded-full transition-all duration-500" style={{ width: `${Math.max(0, Math.min(100, (daysLeft / 30) * 100))}%` }} />
            </div>
          </div>
        )}
      </Card>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <StatCard icon={<Heart className="w-6 h-6" />} label="Likes Given" value={likedCount} color="error" />
        <StatCard icon={<Star className="w-6 h-6" />} label="Ratings Given" value={ratings} color="warning" />
        <StatCard icon={<MessageCircle className="w-6 h-6" />} label="Comments" value={comments} color="primary" />
        <StatCard icon={<Film className="w-6 h-6" />} label="Favorites" value={favorites} color="accent" />
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <Link to="/customize"><Card className="flex items-center gap-4"><div className="w-12 h-12 rounded-xl bg-primary-50 dark:bg-primary-900/30 flex items-center justify-center"><Settings className="w-6 h-6 text-primary-500" /></div><div><h4 className="font-semibold">Customize Profile</h4><p className="text-sm text-slate-500">Update avatar, banner, theme, and more</p></div></Card></Link>
        <Link to={`/profile/${session?.user?.id}`}><Card className="flex items-center gap-4"><div className="w-12 h-12 rounded-xl bg-accent-50 dark:bg-accent-900/30 flex items-center justify-center"><Film className="w-6 h-6 text-accent-500" /></div><div><h4 className="font-semibold">View Public Profile</h4><p className="text-sm text-slate-500">See how others see your page</p></div></Card></Link>
      </div>
    </div>
  );
}
