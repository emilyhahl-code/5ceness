import { useEffect, useState } from 'react';
import { Lightbulb, TrendingUp, Plus, Send } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { useLike } from '@/hooks/useLike';
import { CommentSection } from '@/components/CommentSection';
import { Card, Badge, EmptyState, Modal } from '@/components/ui';
import { Avatar } from '@/components/Avatar';
import type { CommunityRequest, Profile } from '@/types';

export function RequestsPage() {
  const { session } = useAuth();
  const [requests, setRequests] = useState<(CommunityRequest & { profiles?: Pick<Profile, 'username' | 'avatar_url'> })[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newCategory, setNewCategory] = useState('General');
  const [filter, setFilter] = useState<'all' | 'open' | 'in_progress' | 'completed'>('all');

  const fetchRequests = async () => {
    setLoading(true);
    let query = supabase.from('requests').select(`*, profiles:profiles!requests_user_id_fkey (username, avatar_url)`);
    if (filter !== 'all') query = query.eq('status', filter);
    const { data } = await query.order('votes', { ascending: false }).limit(50);
    setRequests(data ?? []);
    setLoading(false);
  };

  useEffect(() => { fetchRequests(); }, [filter]);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!session?.user) return;
    const { error } = await supabase.from('requests').insert({ title: newTitle, description: newDesc, category: newCategory });
    if (!error) { setNewTitle(''); setNewDesc(''); setNewCategory('General'); setShowCreate(false); fetchRequests(); }
  };

  const selectedRequest = requests.find((r) => r.id === selectedId);

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl md:text-4xl font-bold font-display mb-2">Community Requests</h1>
          <p className="text-slate-500">Submit and vote on feature requests.</p>
        </div>
        {session && <button onClick={() => setShowCreate(true)} className="btn-primary flex items-center gap-2"><Plus className="w-5 h-5" /> New Request</button>}
      </div>

      <div className="flex gap-2 mb-6">
        {(['all', 'open', 'in_progress', 'completed'] as const).map((f) => (
          <button key={f} onClick={() => setFilter(f)} className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${filter === f ? 'bg-primary-500 text-white' : 'glass hover:bg-primary-50 dark:hover:bg-primary-900/20'}`}>
            {f === 'all' ? 'All' : f === 'in_progress' ? 'In Progress' : f.charAt(0).toUpperCase() + f.slice(1)}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="space-y-3">{[...Array(4)].map((_, i) => <div key={i} className="h-24 rounded-xl skeleton" />)}</div>
      ) : requests.length === 0 ? (
        <EmptyState icon={<Lightbulb className="w-8 h-8" />} title="No requests yet" message="Be the first to submit a request!" />
      ) : (
        <div className="space-y-3">
          {requests.map((req) => (
            <RequestCard key={req.id} request={req} onOpen={() => setSelectedId(req.id)} canVote={!!session} />
          ))}
        </div>
      )}

      <Modal isOpen={showCreate} onClose={() => setShowCreate(false)} title="New Request">
        <form onSubmit={handleCreate} className="space-y-4">
          <div><label className="block text-sm font-medium mb-1.5">Title</label><input type="text" value={newTitle} onChange={(e) => setNewTitle(e.target.value)} className="input-field" placeholder="Request title" required /></div>
          <div><label className="block text-sm font-medium mb-1.5">Category</label><select value={newCategory} onChange={(e) => setNewCategory(e.target.value)} className="input-field">{['General', 'Feature', 'Bug', 'Improvement', 'Content'].map((c) => <option key={c}>{c}</option>)}</select></div>
          <div><label className="block text-sm font-medium mb-1.5">Description</label><textarea value={newDesc} onChange={(e) => setNewDesc(e.target.value)} className="input-field resize-none" rows={4} placeholder="Describe your request..." required /></div>
          <button type="submit" className="btn-primary w-full flex items-center justify-center gap-2"><Send className="w-4 h-4" /> Submit Request</button>
        </form>
      </Modal>

      <Modal isOpen={!!selectedId} onClose={() => setSelectedId(null)} title={selectedRequest?.title}>
        {selectedRequest && (
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Badge variant={selectedRequest.status === 'open' ? 'success' : selectedRequest.status === 'in_progress' ? 'warning' : 'primary'}>{selectedRequest.status.replace('_', ' ')}</Badge>
              <Badge>{selectedRequest.category}</Badge>
            </div>
            <p className="text-sm text-slate-600 dark:text-slate-300">{selectedRequest.description || 'No description'}</p>
            <div className="flex items-center gap-2 text-sm"><TrendingUp className="w-4 h-4 text-primary-500" /> {selectedRequest.votes} votes</div>
            <div className="border-t border-slate-200/50 dark:border-slate-700/50 pt-4"><CommentSection targetType="request" targetId={selectedRequest.id} /></div>
          </div>
        )}
      </Modal>
    </div>
  );
}

function RequestCard({ request, onOpen, canVote }: { request: CommunityRequest & { profiles?: Pick<Profile, 'username' | 'avatar_url'> }; onOpen: () => void; canVote: boolean }) {
  const { liked, toggleLike, fetchLikeState } = useLike('request', request.id);
  useEffect(() => { fetchLikeState(); }, [fetchLikeState]);

  return (
    <Card className="!p-4">
      <div className="flex items-start gap-4">
        <button onClick={canVote ? toggleLike : undefined} disabled={!canVote} className={`flex flex-col items-center justify-center w-14 h-14 rounded-xl transition-all ${liked ? 'bg-primary-500 text-white' : 'glass hover:bg-primary-50 dark:hover:bg-primary-900/20'} ${!canVote ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}>
          <TrendingUp className="w-5 h-5" /><span className="text-xs font-bold mt-0.5">{request.votes}</span>
        </button>
        <div className="flex-1 min-w-0 cursor-pointer" onClick={onOpen}>
          <div className="flex items-center gap-2 mb-1">
            <h3 className="font-semibold truncate">{request.title}</h3>
            <Badge variant={request.status === 'open' ? 'success' : request.status === 'in_progress' ? 'warning' : 'primary'}>{request.status.replace('_', ' ')}</Badge>
          </div>
          <p className="text-sm text-slate-500 line-clamp-2">{request.description || 'No description'}</p>
          <div className="flex items-center gap-2 mt-2">
            {request.profiles && <Avatar url={request.profiles.avatar_url} username={request.profiles.username} size={20} />}
            <span className="text-xs text-slate-400">{request.profiles?.username || 'Unknown'} · {new Date(request.created_at).toLocaleDateString()}</span>
          </div>
        </div>
      </div>
    </Card>
  );
}
