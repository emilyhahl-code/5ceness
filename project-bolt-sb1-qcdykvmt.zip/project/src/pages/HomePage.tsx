import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Sparkles, Film, GraduationCap, Lightbulb, Globe, Download,
  Heart, Star, Users, TrendingUp, ArrowRight,
  Crown, Newspaper, Megaphone, ChevronRight, Eye,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Card, StatCard, Badge, EmptyState } from '@/components/ui';
import type { Scenepack, Tutorial, CommunityRequest, News, Announcement } from '@/types';

export function HomePage() {
  const [stats, setStats] = useState({
    scenepacks: 0, tutorials: 0, downloads: 0, members: 0, editUploaders: 0, likes: 0,
  });
  const [latestScenepacks, setLatestScenepacks] = useState<Scenepack[]>([]);
  const [trendingScenepacks, setTrendingScenepacks] = useState<Scenepack[]>([]);
  const [latestTutorials, setLatestTutorials] = useState<Tutorial[]>([]);
  const [popularRequests, setPopularRequests] = useState<CommunityRequest[]>([]);
  const [news, setNews] = useState<News[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const [sp, spTrending, tut, req, newsData, ann,
        { count: spCount }, { count: tutCount },
        { count: memberCount }, { count: likeCount },
        { count: uploadMemberCount },
      ] = await Promise.all([
        supabase.from('scenepacks').select('*').order('created_at', { ascending: false }).limit(8),
        supabase.from('scenepacks').select('*').eq('trending', true).order('downloads', { ascending: false }).limit(4),
        supabase.from('tutorials').select('*').order('created_at', { ascending: false }).limit(4),
        supabase.from('requests').select('*').eq('status', 'open').order('votes', { ascending: false }).limit(3),
        supabase.from('news').select('*').order('created_at', { ascending: false }).limit(3),
        supabase.from('announcements').select('*').order('created_at', { ascending: false }).limit(2),
        supabase.from('scenepacks').select('*', { count: 'exact', head: true }),
        supabase.from('tutorials').select('*', { count: 'exact', head: true }),
        supabase.from('profiles').select('*', { count: 'exact', head: true }),
        supabase.from('likes').select('*', { count: 'exact', head: true }),
        supabase.from('edits').select('creator_id', { count: 'exact', head: true }),
      ]);

      const allPacks = sp.data ?? [];
      const totalDownloads = allPacks.reduce((s, p) => s + (p as Scenepack).downloads, 0);

      setLatestScenepacks(allPacks);
      setTrendingScenepacks(spTrending.data ?? []);
      setLatestTutorials(tut.data ?? []);
      setPopularRequests(req.data ?? []);
      setNews(newsData.data ?? []);
      setAnnouncements(ann.data ?? []);
      setStats({
        scenepacks: spCount ?? 0,
        tutorials: tutCount ?? 0,
        downloads: totalDownloads,
        members: memberCount ?? 0,
        editUploaders: uploadMemberCount ?? 0,
        likes: likeCount ?? 0,
      });
      setLoading(false);
    })();
  }, []);

  return (
    <div className="animate-fade-in">
      {/* Hero */}
      <section className="relative overflow-hidden py-20 md:py-32">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-20 left-10 w-72 h-72 bg-primary-300/20 rounded-full blur-3xl animate-float" />
          <div className="absolute bottom-10 right-10 w-96 h-96 bg-accent-300/20 rounded-full blur-3xl animate-float" style={{ animationDelay: '2s' }} />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-6 animate-fade-in-down">
            <Sparkles className="w-4 h-4 text-primary-500" />
            <span className="text-sm font-medium">Premium Community Platform</span>
          </div>
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold font-display mb-6 text-balance">
            Create. Share. <span className="gradient-text">Elevate.</span>
          </h1>
          <p className="text-lg md:text-xl text-slate-600 dark:text-slate-300 max-w-2xl mx-auto mb-8 text-balance">
            Download free scenepacks, purchase professional websites, subscribe to upload edits with custom quality and FPS, and join a growing community of creators.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/scenepacks" className="btn-primary inline-flex items-center justify-center gap-2">
              <Film className="w-5 h-5" /> Browse Scenepacks
            </Link>
            <Link to="/services" className="btn-secondary inline-flex items-center justify-center gap-2">
              <Globe className="w-5 h-5" /> Website Services
            </Link>
          </div>
        </div>
      </section>

      {/* Stats — Total Downloads, Members, Upload Members + more */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          <StatCard icon={<Users className="w-6 h-6" />} label="Members" value={stats.members} color="primary" />
          <StatCard icon={<Download className="w-6 h-6" />} label="Total Downloads" value={stats.downloads} color="success" />
          <StatCard icon={<Crown className="w-6 h-6" />} label="Edit Uploaders" value={stats.editUploaders} color="warning" />
          <StatCard icon={<Film className="w-6 h-6" />} label="Scenepacks" value={stats.scenepacks} color="accent" />
          <StatCard icon={<GraduationCap className="w-6 h-6" />} label="Tutorials" value={stats.tutorials} color="primary" />
          <StatCard icon={<Heart className="w-6 h-6" />} label="Total Likes" value={stats.likes} color="error" />
        </div>
      </section>

      {/* Announcements */}
      {announcements.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          {announcements.map((a) => (
            <div key={a.id} className="glass-card p-4 flex items-start gap-3 mb-2 animate-fade-in-up">
              <div className="w-10 h-10 rounded-lg bg-primary-50 dark:bg-primary-900/30 flex items-center justify-center flex-shrink-0">
                <Megaphone className="w-5 h-5 text-primary-500" />
              </div>
              <div>
                <h4 className="font-semibold text-sm">{a.title}</h4>
                <p className="text-sm text-slate-500 dark:text-slate-400">{a.content}</p>
              </div>
            </div>
          ))}
        </section>
      )}

      {/* Latest Scenepacks */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="section-title">Latest Scenepacks</h2>
            <p className="section-subtitle">Fresh content from the community</p>
          </div>
          <Link to="/scenepacks" className="btn-ghost flex items-center gap-1 text-sm">
            View All <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
        {loading ? (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => <div key={i} className="h-48 rounded-xl skeleton" />)}
          </div>
        ) : latestScenepacks.length === 0 ? (
          <EmptyState icon={<Film className="w-8 h-8" />} title="No scenepacks yet" message="Check back soon!" />
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {latestScenepacks.slice(0, 4).map((sp) => (
              <ScenepackCard key={sp.id} scenepack={sp} />
            ))}
          </div>
        )}
      </section>

      {/* Trending */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="section-title flex items-center gap-2">
              <TrendingUp className="w-7 h-7 text-primary-500" /> Trending Scenepacks
            </h2>
            <p className="section-subtitle">Most downloaded this week</p>
          </div>
        </div>
        {trendingScenepacks.length === 0 ? (
          <EmptyState icon={<TrendingUp className="w-8 h-8" />} title="No trending scenepacks" message="No trending packs right now." />
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {trendingScenepacks.map((sp) => (
              <ScenepackCard key={sp.id} scenepack={sp} trending />
            ))}
          </div>
        )}
      </section>

      {/* Latest Tutorials + Popular Requests */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid lg:grid-cols-2 gap-8">
          <div>
            <div className="flex items-center justify-between mb-6">
              <h2 className="section-title flex items-center gap-2">
                <GraduationCap className="w-7 h-7 text-primary-500" /> Latest Tutorials
              </h2>
              <Link to="/tutorials" className="btn-ghost text-sm">View All</Link>
            </div>
            {latestTutorials.length === 0 ? (
              <Card hover={false} className="text-center py-8 text-slate-500 text-sm">No tutorials yet.</Card>
            ) : (
              <div className="space-y-3">
                {latestTutorials.slice(0, 3).map((t) => (
                  <Card key={t.id} className="!p-4">
                    <div className="flex items-start gap-3">
                      <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-primary-400 to-accent-500 flex items-center justify-center flex-shrink-0">
                        <GraduationCap className="w-6 h-6 text-white" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-semibold truncate">{t.title}</h4>
                        <p className="text-sm text-slate-500 line-clamp-1">{t.description}</p>
                        <div className="flex items-center gap-3 mt-1 text-xs text-slate-400">
                          <span className="flex items-center gap-1"><Eye className="w-3 h-3" /> {t.views} views</span>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </div>

          <div>
            <div className="flex items-center justify-between mb-6">
              <h2 className="section-title flex items-center gap-2">
                <Lightbulb className="w-7 h-7 text-primary-500" /> Popular Requests
              </h2>
              <Link to="/requests" className="btn-ghost text-sm">View All</Link>
            </div>
            {popularRequests.length === 0 ? (
              <Card hover={false} className="text-center py-8 text-slate-500 text-sm">No requests yet.</Card>
            ) : (
              <div className="space-y-3">
                {popularRequests.map((r) => (
                  <Card key={r.id} className="!p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <h4 className="font-semibold truncate">{r.title}</h4>
                        <p className="text-sm text-slate-500 line-clamp-1">{r.description}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant={r.status === 'open' ? 'success' : r.status === 'in_progress' ? 'warning' : 'primary'}>
                            {r.status.replace('_', ' ')}
                          </Badge>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 text-primary-500 font-semibold text-sm">
                        <TrendingUp className="w-4 h-4" /> {r.votes}
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Website Services CTA */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Card hover={false} className="relative overflow-hidden p-8 md:p-12">
          <div className="absolute inset-0 pointer-events-none">
            <div className="absolute top-0 right-0 w-64 h-64 bg-primary-300/20 rounded-full blur-3xl" />
          </div>
          <div className="relative grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="section-title">Professional Websites for Creators</h2>
              <p className="section-subtitle">
                Get a stunning website built for you. Basic package from €45, premium up to €100.
                Order form, portfolio, service details, and PayPal payment — all in one place.
              </p>
              <Link to="/services" className="btn-primary inline-flex items-center gap-2">
                Explore Services <ArrowRight className="w-5 h-5" />
              </Link>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="glass-card p-5 text-center">
                <Globe className="w-8 h-8 mx-auto mb-2 text-primary-500" />
                <h4 className="font-semibold">Basic</h4>
                <p className="text-2xl font-bold gradient-text">€45</p>
              </div>
              <div className="glass-card p-5 text-center">
                <Sparkles className="w-8 h-8 mx-auto mb-2 text-primary-500" />
                <h4 className="font-semibold">Premium</h4>
                <p className="text-2xl font-bold gradient-text">€100</p>
              </div>
            </div>
          </div>
        </Card>
      </section>

      {/* News */}
      {news.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="flex items-center justify-between mb-6">
            <h2 className="section-title flex items-center gap-2">
              <Newspaper className="w-7 h-7 text-primary-500" /> Latest News
            </h2>
          </div>
          <div className="grid md:grid-cols-3 gap-4">
            {news.map((n) => (
              <Card key={n.id}>
                {n.image_url && (
                  <img src={n.image_url} alt={n.title} className="w-full h-40 object-cover rounded-lg mb-4" />
                )}
                <h4 className="font-semibold mb-2">{n.title}</h4>
                <p className="text-sm text-slate-500 line-clamp-3">{n.content}</p>
                <p className="text-xs text-slate-400 mt-3">{new Date(n.created_at).toLocaleDateString()}</p>
              </Card>
            ))}
          </div>
        </section>
      )}

      {/* Membership CTA */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Card hover={false} className="p-8 md:p-12 text-center relative overflow-hidden">
          <div className="absolute inset-0 pointer-events-none">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-accent-300/15 rounded-full blur-3xl" />
          </div>
          <div className="relative">
            <Crown className="w-12 h-12 mx-auto mb-4 text-primary-500" />
            <h2 className="section-title">Upload Membership</h2>
            <p className="section-subtitle max-w-xl mx-auto">
              Subscribe for just €1.50/month and unlock the ability to upload your own edits with custom quality and FPS settings.
              Admins get free access automatically.
            </p>
            <Link to="/membership" className="btn-primary inline-flex items-center gap-2">
              <Crown className="w-5 h-5" /> Become a Member
            </Link>
          </div>
        </Card>
      </section>
    </div>
  );
}

function ScenepackCard({ scenepack, trending = false }: { scenepack: Scenepack; trending?: boolean }) {
  return (
    <Link to={`/scenepacks/${scenepack.id}`}>
      <Card className="!p-0 overflow-hidden h-full">
        <div className="relative h-32 md:h-40 bg-gradient-to-br from-primary-400 to-accent-500">
          {scenepack.thumbnail_url ? (
            <img src={scenepack.thumbnail_url} alt={scenepack.title} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <Film className="w-10 h-10 text-white/70" />
            </div>
          )}
          {trending && (
            <div className="absolute top-2 right-2">
              <Badge variant="warning"><TrendingUp className="w-3 h-3" /> Trending</Badge>
            </div>
          )}
        </div>
        <div className="p-4">
          <h4 className="font-semibold text-sm truncate">{scenepack.title}</h4>
          <p className="text-xs text-slate-500 mb-2">{scenepack.category}</p>
          <div className="flex items-center gap-3 text-xs text-slate-400">
            <span className="flex items-center gap-1"><Download className="w-3 h-3" /> {scenepack.downloads}</span>
            <span className="flex items-center gap-1"><Eye className="w-3 h-3" /> {scenepack.views}</span>
          </div>
        </div>
      </Card>
    </Link>
  );
}
