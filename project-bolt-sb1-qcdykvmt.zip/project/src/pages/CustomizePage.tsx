import { useState } from 'react';
import { Sparkles, Moon, Sun, User, Check, Image } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useTheme } from '@/context/ThemeContext';
import { Card, Badge } from '@/components/ui';
import { Avatar } from '@/components/Avatar';
import { BACKGROUND_THEMES, ACCENT_COLORS } from '@/types';

export function CustomizePage() {
  const { profile, updateProfile } = useAuth();
  const { theme, toggleTheme, backgroundTheme, setBackgroundTheme, accentColor, setAccentColor } = useTheme();
  const [username, setUsername] = useState(profile?.username ?? '');
  const [fullName, setFullName] = useState(profile?.full_name ?? '');
  const [bio, setBio] = useState(profile?.bio ?? '');
  const [avatarUrl, setAvatarUrl] = useState(profile?.avatar_url ?? '');
  const [bannerUrl, setBannerUrl] = useState(profile?.banner_url ?? '');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    await updateProfile({ username, full_name: fullName || null, bio: bio || null, avatar_url: avatarUrl || null, banner_url: bannerUrl || null });
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in">
      <div className="mb-8">
        <h1 className="text-3xl font-bold font-display mb-2 flex items-center gap-2"><Sparkles className="w-8 h-8 text-primary-500" /> Customize</h1>
        <p className="text-slate-500">Personalize your profile and experience.</p>
      </div>

      <div className="space-y-6">
        <Card hover={false}>
          <h2 className="text-xl font-bold mb-4 flex items-center gap-2"><User className="w-5 h-5 text-primary-500" /> Profile Info</h2>
          <form onSubmit={handleSave} className="space-y-4">
            <div className="flex items-center gap-4 mb-4">
              <Avatar url={avatarUrl || profile?.avatar_url} username={username || profile?.username || 'U'} size={64} />
              <div className="flex-1"><label className="block text-sm font-medium mb-1">Avatar URL</label><input type="url" value={avatarUrl} onChange={(e) => setAvatarUrl(e.target.value)} className="input-field" placeholder="https://..." /></div>
            </div>
            <div className="grid md:grid-cols-2 gap-4">
              <div><label className="block text-sm font-medium mb-1">Username</label><input type="text" value={username} onChange={(e) => setUsername(e.target.value)} className="input-field" required /></div>
              <div><label className="block text-sm font-medium mb-1">Full Name</label><input type="text" value={fullName} onChange={(e) => setFullName(e.target.value)} className="input-field" /></div>
            </div>
            <div><label className="block text-sm font-medium mb-1">Bio</label><textarea value={bio} onChange={(e) => setBio(e.target.value)} className="input-field resize-none" rows={3} placeholder="Tell us about yourself..." /></div>
            <div><label className="block text-sm font-medium mb-1">Banner URL</label><input type="url" value={bannerUrl} onChange={(e) => setBannerUrl(e.target.value)} className="input-field" placeholder="https://..." /></div>
            <button type="submit" disabled={saving} className="btn-primary flex items-center gap-2 disabled:opacity-50">{saved ? <><Check className="w-5 h-5" /> Saved!</> : saving ? 'Saving...' : 'Save Profile'}</button>
          </form>
        </Card>

        <Card hover={false}>
          <h2 className="text-xl font-bold mb-4 flex items-center gap-2"><Moon className="w-5 h-5 text-primary-500" /> Appearance</h2>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Mode</label>
              <div className="flex gap-3">
                <button onClick={() => theme === 'dark' && toggleTheme()} className={`flex-1 p-4 rounded-xl border-2 transition-all ${theme === 'light' ? 'border-primary-400 bg-primary-50 dark:bg-primary-900/20' : 'border-transparent glass'}`}><Sun className="w-6 h-6 mx-auto mb-2 text-warning-500" /><span className="text-sm font-medium">Light</span></button>
                <button onClick={() => theme === 'light' && toggleTheme()} className={`flex-1 p-4 rounded-xl border-2 transition-all ${theme === 'dark' ? 'border-primary-400 bg-primary-50 dark:bg-primary-900/20' : 'border-transparent glass'}`}><Moon className="w-6 h-6 mx-auto mb-2 text-primary-500" /><span className="text-sm font-medium">Dark</span></button>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Background Theme</label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {BACKGROUND_THEMES.map((bg) => (
                  <button key={bg.id} onClick={() => setBackgroundTheme(bg.id)} className={`relative p-4 rounded-xl border-2 transition-all ${backgroundTheme === bg.id ? 'border-primary-400' : 'border-transparent glass'}`}>
                    <div className={`w-full h-16 rounded-lg ${bg.className} mb-2`} />
                    <span className="text-sm font-medium">{bg.name}</span>
                    {backgroundTheme === bg.id && <Check className="absolute top-2 right-2 w-4 h-4 text-primary-500" />}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Accent Color</label>
              <div className="flex flex-wrap gap-3">
                {ACCENT_COLORS.map((c) => (
                  <button key={c.id} onClick={() => setAccentColor(c.id)} className={`w-12 h-12 rounded-xl transition-all ${accentColor === c.id ? 'ring-2 ring-offset-2 ring-primary-400 scale-110' : 'hover:scale-105'}`} style={{ backgroundColor: c.value }} title={c.name}>{accentColor === c.id && <Check className="w-5 h-5 text-white mx-auto" />}</button>
                ))}
              </div>
            </div>
          </div>
        </Card>

        <Card hover={false}>
          <h2 className="text-xl font-bold mb-4 flex items-center gap-2"><Image className="w-5 h-5 text-primary-500" /> Preview</h2>
          <div className={`p-6 rounded-xl ${BACKGROUND_THEMES.find((t) => t.id === backgroundTheme)?.className}`}>
            <div className="glass-card p-4 flex items-center gap-3">
              <Avatar url={avatarUrl || profile?.avatar_url} username={username || profile?.username || 'U'} size={48} />
              <div><p className="font-semibold">{username || profile?.username}</p><p className="text-sm text-slate-500">{bio || 'No bio yet'}</p></div>
              <Badge variant="primary" className="ml-auto">Preview</Badge>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
