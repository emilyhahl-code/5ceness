import { useState } from 'react';
import { Globe, Check, Send, Star, ShoppingCart, Eye } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { Card, Badge } from '@/components/ui';

const SERVICES = [
  { tier: 'basic' as const, name: 'Basic Website', price: 45, features: ['1-3 page website', 'Responsive design', 'Contact form', 'Basic SEO', 'Delivery in 5 days', '1 revision round'], color: 'from-primary-400 to-secondary-500' },
  { tier: 'premium' as const, name: 'Premium Website', price: 100, features: ['Up to 10 pages', 'Custom animations', 'Advanced SEO', 'E-commerce ready', 'CMS integration', 'Delivery in 10 days', '3 revision rounds', 'Priority support'], color: 'from-accent-400 to-primary-600', featured: true },
];

const PORTFOLIO = [
  { title: 'Creator Portfolio', category: 'Portfolio', image: 'https://images.pexels.com/photos/196645/pexels-photo-196645.jpeg?auto=compress&cs=tinysrgb&w=600' },
  { title: 'E-Commerce Store', category: 'E-Commerce', image: 'https://images.pexels.com/photos/230544/pexels-photo-230544.jpeg?auto=compress&cs=tinysrgb&w=600' },
  { title: 'Business Landing', category: 'Landing Page', image: 'https://images.pexels.com/photos/1181467/pexels-photo-1181467.jpeg?auto=compress&cs=tinysrgb&w=600' },
  { title: 'Agency Website', category: 'Business', image: 'https://images.pexels.com/photos/326576/pexels-photo-326576.jpeg?auto=compress&cs=tinysrgb&w=600' },
];

export function ServicesPage() {
  const { session } = useAuth();
  const [selectedTier, setSelectedTier] = useState<'basic' | 'premium'>('basic');
  const [form, setForm] = useState({ name: '', email: '', requirements: '' });
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    const service = SERVICES.find((s) => s.tier === selectedTier)!;
    const { error } = await supabase.from('orders').insert({
      user_id: session?.user?.id ?? null, customer_name: form.name, customer_email: form.email,
      service_tier: selectedTier, price: service.price, requirements: form.requirements,
    });
    if (!error) { setSuccess(true); setForm({ name: '', email: '', requirements: '' }); }
    setSubmitting(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in">
      <div className="text-center mb-12">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-4"><Globe className="w-4 h-4 text-primary-500" /><span className="text-sm font-medium">Professional Website Services</span></div>
        <h1 className="text-3xl md:text-5xl font-bold font-display mb-4">Websites for Creators</h1>
        <p className="text-slate-500 max-w-2xl mx-auto">Get a stunning, modern website built for you. From basic landing pages to full premium sites with e-commerce and CMS.</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6 mb-12">
        {SERVICES.map((service) => (
          <Card key={service.tier} hover={false} className={`relative ${service.featured ? 'ring-2 ring-primary-400 shadow-glow' : ''}`}>
            {service.featured && <div className="absolute -top-3 left-1/2 -translate-x-1/2"><Badge variant="primary"><Star className="w-3 h-3" /> Most Popular</Badge></div>}
            <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${service.color} flex items-center justify-center mb-4`}><Globe className="w-7 h-7 text-white" /></div>
            <h3 className="text-xl font-bold mb-1">{service.name}</h3>
            <p className="text-3xl font-bold gradient-text mb-4">€{service.price}</p>
            <ul className="space-y-2 mb-6">
              {service.features.map((f) => (
                <li key={f} className="flex items-center gap-2 text-sm"><Check className="w-4 h-4 text-success-500 flex-shrink-0" /> {f}</li>
              ))}
            </ul>
            <button onClick={() => setSelectedTier(service.tier)} className={`w-full ${selectedTier === service.tier ? 'btn-primary' : 'btn-secondary'}`}>{selectedTier === service.tier ? 'Selected' : 'Select'}</button>
          </Card>
        ))}
      </div>

      <Card hover={false} className="mb-12">
        <h2 className="text-2xl font-bold mb-1">Order Form</h2>
        <p className="text-sm text-slate-500 mb-6">Selected: <span className="font-semibold text-primary-500">{SERVICES.find((s) => s.tier === selectedTier)!.name} (€{SERVICES.find((s) => s.tier === selectedTier)!.price})</span></p>
        {success ? (
          <div className="text-center py-8 animate-scale-in">
            <div className="w-16 h-16 rounded-full bg-success-50 dark:bg-success-900/30 flex items-center justify-center mx-auto mb-4"><Check className="w-8 h-8 text-success-500" /></div>
            <h3 className="text-xl font-bold mb-2">Order Submitted!</h3>
            <p className="text-slate-500 mb-4">We'll contact you at your email shortly.</p>
            <button onClick={() => setSuccess(false)} className="btn-secondary">Place Another Order</button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div><label className="block text-sm font-medium mb-1.5">Your Name</label><input type="text" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="input-field" required placeholder="John Doe" /></div>
              <div><label className="block text-sm font-medium mb-1.5">Email</label><input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="input-field" required placeholder="you@example.com" /></div>
            </div>
            <div><label className="block text-sm font-medium mb-1.5">Requirements</label><textarea value={form.requirements} onChange={(e) => setForm({ ...form, requirements: e.target.value })} className="input-field resize-none" rows={4} placeholder="Describe what you need..." required /></div>
            <div className="flex flex-col sm:flex-row gap-3">
              <button type="submit" disabled={submitting} className="btn-primary flex items-center justify-center gap-2 flex-1 disabled:opacity-50"><Send className="w-5 h-5" /> {submitting ? 'Submitting...' : 'Submit Order'}</button>
              <a href="#" className="btn-secondary flex items-center justify-center gap-2"><ShoppingCart className="w-5 h-5" /> Pay with PayPal</a>
            </div>
          </form>
        )}
      </Card>

      <div className="mb-12">
        <h2 className="section-title">Portfolio</h2>
        <p className="section-subtitle">A selection of our recent work</p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {PORTFOLIO.map((p) => (
            <Card key={p.title} className="!p-0 overflow-hidden group">
              <div className="relative h-40 overflow-hidden">
                <img src={p.image} alt={p.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-3">
                  <div><h4 className="text-white font-semibold text-sm">{p.title}</h4><p className="text-white/70 text-xs">{p.category}</p></div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>

      <Card hover={false}>
        <h2 className="text-xl font-bold mb-4">Contact Us</h2>
        <div className="grid sm:grid-cols-3 gap-4 text-sm">
          <div className="flex items-center gap-2"><Globe className="w-5 h-5 text-primary-500" /> hello@5cenes.com</div>
          <div className="flex items-center gap-2"><Eye className="w-5 h-5 text-primary-500" /> Response within 24h</div>
          <div className="flex items-center gap-2"><ShoppingCart className="w-5 h-5 text-primary-500" /> PayPal accepted</div>
        </div>
      </Card>
    </div>
  );
}
