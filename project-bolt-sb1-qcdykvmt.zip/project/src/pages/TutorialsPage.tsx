import { useEffect, useState } from 'react';
import { GraduationCap, Eye, Search, X } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Card, EmptyState, Badge } from '@/components/ui';
import type { Tutorial } from '@/types';

export function TutorialsPage() {
  const [tutorials, setTutorials] = useState<Tutorial[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    (async () => {
      let query = supabase.from('tutorials').select('*').order('created_at', { ascending: false });
      if (search.trim()) query = query.or(`title.ilike.%${search}%,description.ilike.%${search}%`);
      const { data } = await query.limit(60);
      setTutorials(data ?? []);
      setLoading(false);
    })();
  }, [search]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in">
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold font-display mb-2">Tutorials</h1>
        <p className="text-slate-500">Learn from the best with our collection of tutorials.</p>
      </div>
      <div className="glass-card p-4 mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input type="text" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search tutorials..." className="input-field pl-10" />
          {search && <button onClick={() => setSearch('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400"><X className="w-4 h-4" /></button>}
        </div>
      </div>
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">{[...Array(6)].map((_, i) => <div key={i} className="h-48 rounded-xl skeleton" />)}</div>
      ) : tutorials.length === 0 ? (
        <EmptyState icon={<GraduationCap className="w-8 h-8" />} title="No tutorials found" message="Check back soon for new tutorials!" />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {tutorials.map((t) => (
            <Card key={t.id} className="!p-0 overflow-hidden">
              <div className="relative h-40 bg-gradient-to-br from-primary-400 to-accent-500">
                {t.thumbnail_url ? <img src={t.thumbnail_url} alt={t.title} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center"><GraduationCap className="w-12 h-12 text-white/70" /></div>}
                {t.video_url && <div className="absolute inset-0 flex items-center justify-center"><div className="w-14 h-14 rounded-full glass flex items-center justify-center"><svg className="w-6 h-6 text-white ml-1" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg></div></div>}
              </div>
              <div className="p-4">
                <h3 className="font-semibold truncate">{t.title}</h3>
                <p className="text-sm text-slate-500 line-clamp-2 mt-1">{t.description || 'No description'}</p>
                <div className="flex items-center gap-3 mt-3 text-xs text-slate-400">
                  <span className="flex items-center gap-1"><Eye className="w-3 h-3" /> {t.views} views</span>
                  <Badge>{new Date(t.created_at).toLocaleDateString()}</Badge>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
