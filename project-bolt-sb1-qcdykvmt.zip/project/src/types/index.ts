export type Profile = {
  id: string;
  username: string;
  full_name: string | null;
  bio: string | null;
  avatar_url: string | null;
  banner_url: string | null;
  is_admin: boolean;
  theme: 'light' | 'dark';
  accent_color: string;
  background_theme: string;
  created_at: string;
  updated_at: string;
};

export type Edit = {
  id: string;
  title: string;
  description: string;
  video_url: string | null;
  thumbnail_url: string | null;
  quality: string;
  fps: number;
  creator_id: string | null;
  downloads: number;
  views: number;
  created_at: string;
  updated_at: string;
};

export const EDIT_QUALITIES = ['720p', '1080p', '1440p', '4K'];
export const EDIT_FPS_OPTIONS = [24, 30, 60, 120];

export type Scenepack = {
  id: string;
  title: string;
  description: string;
  category: string;
  thumbnail_url: string | null;
  download_url: string | null;
  creator_id: string | null;
  downloads: number;
  views: number;
  trending: boolean;
  created_at: string;
  updated_at: string;
};

export type Tutorial = {
  id: string;
  title: string;
  description: string;
  video_url: string | null;
  thumbnail_url: string | null;
  creator_id: string | null;
  views: number;
  created_at: string;
  updated_at: string;
};

export type CommunityRequest = {
  id: string;
  title: string;
  description: string;
  category: string;
  status: 'open' | 'in_progress' | 'completed';
  user_id: string;
  votes: number;
  created_at: string;
  updated_at: string;
};

export type Comment = {
  id: string;
  content: string;
  user_id: string;
  target_type: 'scenepack' | 'tutorial' | 'request';
  target_id: string;
  parent_id: string | null;
  created_at: string;
  profiles?: Pick<Profile, 'username' | 'avatar_url'>;
};

export type Like = {
  id: string;
  user_id: string;
  target_type: 'scenepack' | 'tutorial' | 'request' | 'comment';
  target_id: string;
  created_at: string;
};

export type Rating = {
  id: string;
  user_id: string;
  scenepack_id: string;
  rating: number;
  created_at: string;
};

export type Favorite = {
  id: string;
  user_id: string;
  scenepack_id: string;
  created_at: string;
};

export type Subscription = {
  id: string;
  user_id: string;
  status: 'active' | 'expired' | 'cancelled';
  start_date: string;
  end_date: string;
  amount: number;
  payment_method: string;
  created_at: string;
};

export type Order = {
  id: string;
  user_id: string | null;
  customer_name: string;
  customer_email: string;
  service_tier: 'basic' | 'premium';
  price: number;
  requirements: string;
  status: 'pending' | 'in_progress' | 'completed' | 'cancelled';
  created_at: string;
};

export type Announcement = {
  id: string;
  title: string;
  content: string;
  created_at: string;
};

export type News = {
  id: string;
  title: string;
  content: string;
  image_url: string | null;
  created_at: string;
};

export type Follow = {
  id: string;
  follower_id: string;
  following_id: string;
  created_at: string;
};

export type Notification = {
  id: string;
  user_id: string;
  type: 'like' | 'comment' | 'follow' | 'reply' | 'system';
  message: string;
  link: string | null;
  read: boolean;
  created_at: string;
};

export type Achievement = {
  id: string;
  name: string;
  description: string;
  icon: string;
  requirement: string;
  created_at: string;
};

export type UserAchievement = {
  id: string;
  user_id: string;
  achievement_id: string;
  created_at: string;
};

export type TargetType = 'scenepack' | 'tutorial' | 'request' | 'comment';

export type ThemeOption = {
  id: string;
  name: string;
  className: string;
};

export const BACKGROUND_THEMES: ThemeOption[] = [
  { id: 'aurora', name: 'Aurora', className: 'bg-theme-aurora' },
  { id: 'mesh', name: 'Mesh', className: 'bg-theme-mesh' },
  { id: 'waves', name: 'Waves', className: 'bg-theme-waves' },
  { id: 'geometric', name: 'Geometric', className: 'bg-theme-geometric' },
  { id: 'minimal', name: 'Minimal', className: 'bg-theme-minimal' },
];

export const ACCENT_COLORS = [
  { id: 'blue', name: 'Blue', value: '#3b9af7' },
  { id: 'cyan', name: 'Cyan', value: '#06b6d4' },
  { id: 'green', name: 'Green', value: '#22c55e' },
  { id: 'amber', name: 'Amber', value: '#f59e0b' },
  { id: 'rose', name: 'Rose', value: '#f43f5e' },
  { id: 'teal', name: 'Teal', value: '#14b8a6' },
];

export const SCENEPACK_CATEGORIES = [
  'All', 'General', 'Cinematic', 'VFX', 'Transitions', 'Color Grading', 'Audio', '3D', 'Motion Graphics', 'Intro', 'Outro',
];
