import { Link } from 'react-router-dom';
import { Sparkles, Github, Twitter, Youtube, Mail } from 'lucide-react';

export function Footer() {
  return (
    <footer className="mt-20 border-t border-slate-200/50 dark:border-slate-700/50 glass-nav">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-1">
            <Link to="/" className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-primary-400 to-accent-500 flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold font-display gradient-text">5CENES</span>
            </Link>
            <p className="text-sm text-slate-500 dark:text-slate-400">
              A modern community platform for creators. Download free scenepacks, purchase professional websites, and join a growing editing community.
            </p>
          </div>

          {/* Explore */}
          <div>
            <h4 className="font-semibold mb-4 text-sm">Explore</h4>
            <ul className="space-y-2 text-sm text-slate-500 dark:text-slate-400">
              <li><Link to="/scenepacks" className="hover:text-primary-500 transition-colors">Scenepacks</Link></li>
              <li><Link to="/tutorials" className="hover:text-primary-500 transition-colors">Tutorials</Link></li>
              <li><Link to="/requests" className="hover:text-primary-500 transition-colors">Requests</Link></li>
              <li><Link to="/services" className="hover:text-primary-500 transition-colors">Website Services</Link></li>
              <li><Link to="/leaderboard" className="hover:text-primary-500 transition-colors">Leaderboard</Link></li>
            </ul>
          </div>

          {/* Community */}
          <div>
            <h4 className="font-semibold mb-4 text-sm">Community</h4>
            <ul className="space-y-2 text-sm text-slate-500 dark:text-slate-400">
              <li><Link to="/register" className="hover:text-primary-500 transition-colors">Sign Up</Link></li>
              <li><Link to="/login" className="hover:text-primary-500 transition-colors">Sign In</Link></li>
              <li><Link to="/membership" className="hover:text-primary-500 transition-colors">Upload Membership</Link></li>
              <li><Link to="/customize" className="hover:text-primary-500 transition-colors">Customize</Link></li>
            </ul>
          </div>

          {/* Connect */}
          <div>
            <h4 className="font-semibold mb-4 text-sm">Connect</h4>
            <div className="flex gap-3">
              <a href="#" className="w-10 h-10 rounded-xl glass flex items-center justify-center hover:shadow-glow-sm transition-all" aria-label="Discord">
                <svg className="w-5 h-5 text-primary-500" viewBox="0 0 24 24" fill="currentColor"><path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/></svg>
              </a>
              <a href="#" className="w-10 h-10 rounded-xl glass flex items-center justify-center hover:shadow-glow-sm transition-all" aria-label="YouTube">
                <Youtube className="w-5 h-5 text-primary-500" />
              </a>
              <a href="#" className="w-10 h-10 rounded-xl glass flex items-center justify-center hover:shadow-glow-sm transition-all" aria-label="Twitter">
                <Twitter className="w-5 h-5 text-primary-500" />
              </a>
              <a href="#" className="w-10 h-10 rounded-xl glass flex items-center justify-center hover:shadow-glow-sm transition-all" aria-label="Email">
                <Mail className="w-5 h-5 text-primary-500" />
              </a>
            </div>
            <div className="mt-4 flex gap-3">
              <a href="#" className="btn-secondary text-sm flex-1 text-center">Discord</a>
              <a href="#" className="btn-primary text-sm flex-1 text-center">PayPal</a>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-slate-200/50 dark:border-slate-700/50 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-sm text-slate-500 dark:text-slate-400">
            © {new Date().getFullYear()} 5CENES. All rights reserved.
          </p>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Built for creators, by creators.
          </p>
        </div>
      </div>
    </footer>
  );
}
