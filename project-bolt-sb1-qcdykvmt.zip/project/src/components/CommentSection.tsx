import { useState, useEffect } from 'react';
import { MessageCircle, Send, Trash2, Reply, Heart } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useComments } from '@/hooks/useComments';
import { useLike } from '@/hooks/useLike';
import { Avatar } from '@/components/Avatar';
import { Card } from '@/components/ui';
import type { Comment } from '@/types';

type CommentWithProfile = Comment & { profiles?: { username: string; avatar_url: string | null } };

export function CommentSection({ targetType, targetId }: { targetType: 'scenepack' | 'tutorial' | 'request'; targetId: string }) {
  const { session, profile } = useAuth();
  const { comments, loading, addComment, deleteComment } = useComments(targetType, targetId);
  const [newComment, setNewComment] = useState('');
  const [replyTo, setReplyTo] = useState<string | null>(null);
  const [replyContent, setReplyContent] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;
    const { error } = await addComment(newComment);
    if (!error) setNewComment('');
  };

  const handleReply = async (parentId: string) => {
    if (!replyContent.trim()) return;
    const { error } = await addComment(replyContent, parentId);
    if (!error) {
      setReplyContent('');
      setReplyTo(null);
    }
  };

  // Group comments by parent
  const topLevel = comments.filter((c) => !c.parent_id);
  const getReplies = (parentId: string) => comments.filter((c) => c.parent_id === parentId);

  return (
    <div className="space-y-4">
      <h3 className="text-xl font-bold flex items-center gap-2">
        <MessageCircle className="w-5 h-5 text-primary-500" /> Comments ({comments.length})
      </h3>

      {/* New comment */}
      {session ? (
        <form onSubmit={handleSubmit} className="glass-card p-4">
          <div className="flex gap-3">
            <Avatar url={profile?.avatar_url} username={profile?.username || 'U'} size={40} />
            <div className="flex-1">
              <textarea
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                placeholder="Write a comment..."
                className="input-field resize-none"
                rows={3}
              />
              <div className="flex justify-end mt-2">
                <button type="submit" disabled={!newComment.trim()} className="btn-primary text-sm disabled:opacity-50 flex items-center gap-2">
                  <Send className="w-4 h-4" /> Post Comment
                </button>
              </div>
            </div>
          </div>
        </form>
      ) : (
        <Card hover={false} className="text-center py-6 text-sm text-slate-500">
          <a href="/login" className="text-primary-500 font-semibold">Sign in</a> to leave a comment.
        </Card>
      )}

      {/* Comments list */}
      {loading ? (
        <div className="space-y-3">
          {[...Array(3)].map((_, i) => <div key={i} className="h-20 rounded-xl skeleton" />)}
        </div>
      ) : topLevel.length === 0 ? (
        <Card hover={false} className="text-center py-8 text-sm text-slate-500">
          No comments yet. Be the first to share!
        </Card>
      ) : (
        <div className="space-y-3">
          {topLevel.map((comment) => (
            <CommentItem
              key={comment.id}
              comment={comment}
              replies={getReplies(comment.id)}
              currentUserId={session?.user?.id}
              isAdmin={profile?.is_admin ?? false}
              onDelete={deleteComment}
              onReply={handleReply}
              replyTo={replyTo}
              setReplyTo={setReplyTo}
              replyContent={replyContent}
              setReplyContent={setReplyContent}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function CommentItem({
  comment, replies, currentUserId, isAdmin, onDelete, onReply, replyTo, setReplyTo, replyContent, setReplyContent,
}: {
  comment: CommentWithProfile;
  replies: CommentWithProfile[];
  currentUserId?: string;
  isAdmin: boolean;
  onDelete: (id: string) => void;
  onReply: (parentId: string) => void;
  replyTo: string | null;
  setReplyTo: (id: string | null) => void;
  replyContent: string;
  setReplyContent: (s: string) => void;
}) {
  const canDelete = currentUserId === comment.user_id || isAdmin;
  const { liked, toggleLike, fetchLikeState } = useLike('comment', comment.id);
  useEffect(() => { fetchLikeState(); }, [fetchLikeState]);

  return (
    <div className="space-y-2">
      <Card className="!p-4" hover={false}>
        <div className="flex gap-3">
          <Avatar url={comment.profiles?.avatar_url} username={comment.profiles?.username || 'U'} size={36} />
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-sm">{comment.profiles?.username || 'Unknown'}</span>
              <span className="text-xs text-slate-400">{new Date(comment.created_at).toLocaleDateString()}</span>
            </div>
            <p className="text-sm mt-1 text-slate-600 dark:text-slate-300">{comment.content}</p>
            <div className="flex items-center gap-3 mt-2">
              <button
                onClick={toggleLike}
                className="flex items-center gap-1 text-xs text-slate-400 hover:text-primary-500 transition-colors"
              >
                <Heart className={`w-3.5 h-3.5 ${liked ? 'fill-primary-500 text-primary-500' : ''}`} />
              </button>
              {currentUserId && (
                <button
                  onClick={() => setReplyTo(replyTo === comment.id ? null : comment.id)}
                  className="flex items-center gap-1 text-xs text-slate-400 hover:text-primary-500 transition-colors"
                >
                  <Reply className="w-3.5 h-3.5" /> Reply
                </button>
              )}
              {canDelete && (
                <button
                  onClick={() => onDelete(comment.id)}
                  className="flex items-center gap-1 text-xs text-slate-400 hover:text-error-500 transition-colors ml-auto"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>
        </div>
      </Card>

      {/* Reply form */}
      {replyTo === comment.id && currentUserId && (
        <div className="ml-12 animate-fade-in">
          <div className="flex gap-2">
            <input
              type="text"
              value={replyContent}
              onChange={(e) => setReplyContent(e.target.value)}
              placeholder="Write a reply..."
              className="input-field text-sm"
              onKeyDown={(e) => { if (e.key === 'Enter') onReply(comment.id); }}
            />
            <button onClick={() => onReply(comment.id)} className="btn-primary text-sm px-4">
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Replies */}
      {replies.length > 0 && (
        <div className="ml-12 space-y-2">
          {replies.map((reply) => {
            const canDeleteReply = currentUserId === reply.user_id || isAdmin;
            return (
              <Card key={reply.id} className="!p-3" hover={false}>
                <div className="flex gap-2">
                  <Avatar url={reply.profiles?.avatar_url} username={reply.profiles?.username || 'U'} size={28} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-xs">{reply.profiles?.username || 'Unknown'}</span>
                      <span className="text-xs text-slate-400">{new Date(reply.created_at).toLocaleDateString()}</span>
                    </div>
                    <p className="text-sm mt-1 text-slate-600 dark:text-slate-300">{reply.content}</p>
                    {canDeleteReply && (
                      <button
                        onClick={() => onDelete(reply.id)}
                        className="flex items-center gap-1 text-xs text-slate-400 hover:text-error-500 transition-colors mt-1"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
