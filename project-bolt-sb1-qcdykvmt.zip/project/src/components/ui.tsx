import { type ReactNode } from 'react';

export function Spinner({ className = '' }: { className?: string }) {
  return (
    <div className={`flex items-center justify-center ${className}`}>
      <div className="w-8 h-8 border-3 border-primary-200 border-t-primary-500 rounded-full animate-spin" />
    </div>
  );
}

export function Card({ children, className = '', hover = true }: { children: ReactNode; className?: string; hover?: boolean }) {
  return (
    <div className={`glass-card p-6 ${hover ? 'card-hover' : ''} ${className}`}>
      {children}
    </div>
  );
}

export function Badge({ children, variant = 'primary', className = '' }: { children: ReactNode; variant?: 'primary' | 'success' | 'warning' | 'error'; className?: string }) {
  const classes: Record<string, string> = {
    primary: 'badge-primary',
    success: 'badge-success',
    warning: 'badge-warning',
    error: 'badge-error',
  };
  return <span className={`badge ${classes[variant]} ${className}`}>{children}</span>;
}

export function EmptyState({ icon, title, message }: { icon: ReactNode; title: string; message: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center animate-fade-in">
      <div className="w-16 h-16 rounded-2xl glass flex items-center justify-center mb-4 text-primary-400">
        {icon}
      </div>
      <h3 className="text-lg font-semibold mb-1">{title}</h3>
      <p className="text-sm text-slate-500 dark:text-slate-400 max-w-sm">{message}</p>
    </div>
  );
}

export function StatCard({ icon, label, value, color = 'primary' }: { icon: ReactNode; label: string; value: string | number; color?: string }) {
  const colorMap: Record<string, string> = {
    primary: 'text-primary-500 bg-primary-50 dark:bg-primary-900/30',
    success: 'text-success-500 bg-success-50 dark:bg-success-900/30',
    warning: 'text-warning-500 bg-warning-50 dark:bg-warning-900/30',
    error: 'text-error-500 bg-error-50 dark:bg-error-900/30',
    accent: 'text-accent-500 bg-accent-50 dark:bg-accent-900/30',
  };
  return (
    <div className="glass-card p-5 card-hover">
      <div className="flex items-center gap-4">
        <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${colorMap[color]}`}>
          {icon}
        </div>
        <div>
          <p className="text-2xl font-bold font-display">{value}</p>
          <p className="text-sm text-slate-500 dark:text-slate-400">{label}</p>
        </div>
      </div>
    </div>
  );
}

export function Modal({ isOpen, onClose, children, title }: { isOpen: boolean; onClose: () => void; children: ReactNode; title?: string }) {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-fade-in" onClick={onClose}>
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
      <div className="relative glass-card p-6 w-full max-w-md animate-scale-in" onClick={(e) => e.stopPropagation()}>
        {title && <h2 className="text-xl font-bold mb-4">{title}</h2>}
        {children}
      </div>
    </div>
  );
}

export function ConfirmDialog({ isOpen, onClose, onConfirm, title, message }: { isOpen: boolean; onClose: () => void; onConfirm: () => void; title: string; message: string }) {
  return (
    <Modal isOpen={isOpen} onClose={onClose} title={title}>
      <p className="text-sm text-slate-600 dark:text-slate-300 mb-6">{message}</p>
      <div className="flex gap-3 justify-end">
        <button className="btn-secondary" onClick={onClose}>Cancel</button>
        <button className="btn-primary !bg-error-500" style={{ background: '#ef4444' }} onClick={() => { onConfirm(); onClose(); }}>Confirm</button>
      </div>
    </Modal>
  );
}
