type AvatarProps = {
  url: string | null | undefined;
  username: string;
  size?: number;
};

export function Avatar({ url, username, size = 40 }: AvatarProps) {
  const initials = username
    .split(' ')
    .map((w) => w[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();

  if (url) {
    return (
      <img
        src={url}
        alt={username}
        className="rounded-full object-cover ring-2 ring-primary-200/50 dark:ring-primary-700/30"
        style={{ width: size, height: size }}
      />
    );
  }

  return (
    <div
      className="rounded-full bg-gradient-to-br from-primary-400 to-accent-500 flex items-center justify-center text-white font-semibold ring-2 ring-primary-200/50 dark:ring-primary-700/30"
      style={{ width: size, height: size, fontSize: size * 0.4 }}
    >
      {initials}
    </div>
  );
}
