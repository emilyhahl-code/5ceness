import { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import {
  Home, Film, GraduationCap, Lightbulb, Globe, User, Menu, X,
  Bell, Settings, LogOut, Shield, Sparkles, Moon, Sun, Crown,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useTheme } from '@/context/ThemeContext';
import { Avatar } from './Avatar';

export function Navbar() {
  const { profile, signOut } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  const navLinks = [
    { to: '/', label: 'Home', icon: Home },
    { to: '/scenepacks', label: 'Scenepacks', icon: Film },
    { to: '/tutorials', label: 'Tutorials', icon: GraduationCap },
    { to: '/requests', label: 'Requests', icon: Lightbulb },
    { to: '/services', label: 'Services', icon: Globe },
  ];

  const isActive = (path: string) => path === '/' ? location.pathname === '/' : location.pathname.startsWith(path);

  const handleSignOut = async () => {
    await signOut();
    setUserMenuOpen(false);
    navigate('/');
  };

  return (
    <nav className="sticky top-0 z-40 glass-nav">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 group">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-primary-400 to-accent-500 flex items-center justify-center shadow-glow-sm group-hover:shadow-glow transition-all duration-300">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold font-display gradient-text">5CENES</span>
          </Link>

          {/* Desktop nav */}
          <div className="hidden md:flex items-center gap-1">
            {navLinks.map(({ to, label, icon: Icon }) => (
              <Link
                key={to}
                to={to}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-sm transition-all duration-200 ${
                  isActive(to)
                    ? 'text-primary-600 dark:text-primary-400 bg-primary-50 dark:bg-primary-900/30'
                    : 'text-slate-600 dark:text-slate-300 hover:text-primary-500 hover:bg-primary-50/50 dark:hover:bg-primary-900/20'
                }`}
              >
                <Icon className="w-4 h-4" />
                {label}
              </Link>
            ))}
          </div>

          {/* Right side */}
          <div className="flex items-center gap-2">
            <button
              onClick={toggleTheme}
              className="p-2 rounded-lg btn-ghost"
              aria-label="Toggle theme"
            >
              {theme === 'light' ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
            </button>

            {profile && (
              <Link to="/notifications" className="p-2 rounded-lg btn-ghost relative" aria-label="Notifications">
                <Bell className="w-5 h-5" />
              </Link>
            )}

            {profile ? (
              <div className="relative">
                <button
                  onClick={() => setUserMenuOpen(!userMenuOpen)}
                  className="flex items-center gap-2 p-1 pr-3 rounded-xl glass hover:shadow-glow-sm transition-all duration-200"
                >
                  <Avatar url={profile.avatar_url} username={profile.username} size={32} />
                  <span className="hidden sm:block text-sm font-medium max-w-[100px] truncate">{profile.username}</span>
                </button>

                {userMenuOpen && (
                  <>
                    <div className="fixed inset-0 z-40" onClick={() => setUserMenuOpen(false)} />
                    <div className="absolute right-0 mt-2 w-56 glass-card p-2 animate-scale-in z-50">
                      <div className="px-3 py-2 border-b border-slate-200/50 dark:border-slate-700/50 mb-2">
                        <p className="text-sm font-semibold truncate">{profile.username}</p>
                        <p className="text-xs text-slate-500 truncate">{profile.full_name || profile.username}</p>
                      </div>
                      <Link to={`/profile/${profile.id}`} onClick={() => setUserMenuOpen(false)} className="flex items-center gap-3 px-3 py-2 rounded-lg btn-ghost w-full text-left">
                        <User className="w-4 h-4" /> Profile
                      </Link>
                      <Link to="/dashboard" onClick={() => setUserMenuOpen(false)} className="flex items-center gap-3 px-3 py-2 rounded-lg btn-ghost w-full text-left">
                        <Settings className="w-4 h-4" /> Dashboard
                      </Link>
                      {profile.is_admin && (
                        <Link to="/admin" onClick={() => setUserMenuOpen(false)} className="flex items-center gap-3 px-3 py-2 rounded-lg btn-ghost w-full text-left text-primary-600 dark:text-primary-400">
                          <Shield className="w-4 h-4" /> Admin Panel
                        </Link>
                      )}
                      <Link to="/customize" onClick={() => setUserMenuOpen(false)} className="flex items-center gap-3 px-3 py-2 rounded-lg btn-ghost w-full text-left">
                        <Sparkles className="w-4 h-4" /> Customize
                      </Link>
                      <button onClick={handleSignOut} className="flex items-center gap-3 px-3 py-2 rounded-lg btn-ghost w-full text-left text-error-500">
                        <LogOut className="w-4 h-4" /> Sign Out
                      </button>
                    </div>
                  </>
                )}
              </div>
            ) : (
              <div className="hidden sm:flex items-center gap-2">
                <Link to="/login" className="btn-ghost">Sign In</Link>
                <Link to="/register" className="btn-primary text-sm">Get Started</Link>
              </div>
            )}

            {/* Mobile menu button */}
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="md:hidden p-2 rounded-lg btn-ghost"
              aria-label="Menu"
            >
              {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="md:hidden glass-nav border-t border-slate-200/50 dark:border-slate-700/50 animate-fade-in-down">
          <div className="px-4 py-4 space-y-1">
            {navLinks.map(({ to, label, icon: Icon }) => (
              <Link
                key={to}
                to={to}
                onClick={() => setMobileOpen(false)}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg font-medium transition-all ${
                  isActive(to)
                    ? 'text-primary-600 dark:text-primary-400 bg-primary-50 dark:bg-primary-900/30'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                <Icon className="w-5 h-5" />
                {label}
              </Link>
            ))}
            {!profile && (
              <div className="pt-2 space-y-2">
                <Link to="/login" onClick={() => setMobileOpen(false)} className="block btn-secondary w-full text-center">Sign In</Link>
                <Link to="/register" onClick={() => setMobileOpen(false)} className="block btn-primary w-full text-center">Get Started</Link>
              </div>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}

export function MembershipBadge({ isAdmin }: { isAdmin: boolean }) {
  if (isAdmin) {
    return (
      <span className="badge badge-warning gap-1">
        <Crown className="w-3 h-3" /> Admin
      </span>
    );
  }
  return null;
}
