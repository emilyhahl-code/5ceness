import { useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type { TargetType } from '@/types';

export function useLike(targetType: TargetType, targetId: string) {
  const { session } = useAuth();
  const [liked, setLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(0);
  const [loading, setLoading] = useState(false);

  const fetchLikeState = useCallback(async () => {
    const { count } = await supabase
      .from('likes')
      .select('*', { count: 'exact', head: true })
      .eq('target_type', targetType)
      .eq('target_id', targetId);
    setLikeCount(count ?? 0);

    if (session?.user) {
      const { data } = await supabase
        .from('likes')
        .select('id')
        .eq('target_type', targetType)
        .eq('target_id', targetId)
        .eq('user_id', session.user.id)
        .maybeSingle();
      setLiked(!!data);
    }
  }, [targetType, targetId, session?.user]);

  const toggleLike = useCallback(async () => {
    if (!session?.user) return { error: 'Not authenticated' };
    setLoading(true);
    if (liked) {
      const { error } = await supabase
        .from('likes')
        .delete()
        .eq('target_type', targetType)
        .eq('target_id', targetId)
        .eq('user_id', session.user.id);
      if (!error) {
        setLiked(false);
        setLikeCount((c) => Math.max(0, c - 1));
      }
      setLoading(false);
      return { error: error?.message ?? null };
    } else {
      const { error } = await supabase
        .from('likes')
        .insert({ target_type: targetType, target_id: targetId });
      if (!error) {
        setLiked(true);
        setLikeCount((c) => c + 1);
      }
      setLoading(false);
      return { error: error?.message ?? null };
    }
  }, [targetType, targetId, session?.user, liked]);

  return { liked, likeCount, loading, toggleLike, fetchLikeState };
}
