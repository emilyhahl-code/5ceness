import { useState, useCallback, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type { Comment, Profile } from '@/types';

type CommentWithProfile = Comment & { profiles?: Pick<Profile, 'username' | 'avatar_url'> };

export function useComments(targetType: 'scenepack' | 'tutorial' | 'request', targetId: string) {
  const { session } = useAuth();
  const [comments, setComments] = useState<CommentWithProfile[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchComments = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('comments')
      .select(`
        *,
        profiles:profiles!comments_user_id_fkey (username, avatar_url)
      `)
      .eq('target_type', targetType)
      .eq('target_id', targetId)
      .order('created_at', { ascending: true });
    if (!error && data) {
      setComments(data as CommentWithProfile[]);
    }
    setLoading(false);
  }, [targetType, targetId]);

  useEffect(() => {
    fetchComments();
  }, [fetchComments]);

  const addComment = useCallback(async (content: string, parentId?: string | null) => {
    if (!session?.user) return { error: 'Not authenticated' };
    const { data, error } = await supabase
      .from('comments')
      .insert({
        content,
        target_type: targetType,
        target_id: targetId,
        parent_id: parentId ?? null,
      })
      .select(`
        *,
        profiles:profiles!comments_user_id_fkey (username, avatar_url)
      `)
      .single();
    if (!error && data) {
      setComments((prev) => [...prev, data as CommentWithProfile]);
    }
    return { error: error?.message ?? null };
  }, [targetType, targetId, session?.user]);

  const deleteComment = useCallback(async (commentId: string) => {
    const { error } = await supabase.from('comments').delete().eq('id', commentId);
    if (!error) {
      setComments((prev) => prev.filter((c) => c.id !== commentId));
    }
    return { error: error?.message ?? null };
  }, []);

  return { comments, loading, addComment, deleteComment, refetch: fetchComments };
}
