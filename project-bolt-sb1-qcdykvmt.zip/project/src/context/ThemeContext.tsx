import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { useAuth } from './AuthContext';
import { BACKGROUND_THEMES } from '@/types';

type ThemeContextValue = {
  theme: 'light' | 'dark';
  toggleTheme: () => void;
  backgroundTheme: string;
  setBackgroundTheme: (theme: string) => void;
  accentColor: string;
  setAccentColor: (color: string) => void;
};

const ThemeContext = createContext<ThemeContextValue | undefined>(undefined);

export function ThemeProvider({ children }: { children: ReactNode }) {
  const { profile, updateProfile } = useAuth();
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [backgroundTheme, setBackgroundThemeState] = useState('aurora');
  const [accentColor, setAccentColorState] = useState('blue');

  // Load from profile or localStorage
  useEffect(() => {
    if (profile) {
      setTheme(profile.theme === 'dark' ? 'dark' : 'light');
      setBackgroundThemeState(profile.background_theme || 'aurora');
      setAccentColorState(profile.accent_color || 'blue');
    } else {
      const saved = localStorage.getItem('5cenes-theme');
      if (saved === 'dark' || saved === 'light') setTheme(saved);
      const savedBg = localStorage.getItem('5cenes-bg-theme');
      if (savedBg) setBackgroundThemeState(savedBg);
      const savedAccent = localStorage.getItem('5cenes-accent');
      if (savedAccent) setAccentColorState(savedAccent);
    }
  }, [profile]);

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    if (profile) {
      localStorage.setItem('5cenes-theme', theme);
    } else {
      localStorage.setItem('5cenes-theme', theme);
    }
  }, [theme, profile]);

  const toggleTheme = () => {
    const next = theme === 'light' ? 'dark' : 'light';
    setTheme(next);
    if (profile) updateProfile({ theme: next });
  };

  const setBackgroundTheme = (bgTheme: string) => {
    setBackgroundThemeState(bgTheme);
    localStorage.setItem('5cenes-bg-theme', bgTheme);
    if (profile) updateProfile({ background_theme: bgTheme });
  };

  const setAccentColor = (color: string) => {
    setAccentColorState(color);
    localStorage.setItem('5cenes-accent', color);
    if (profile) updateProfile({ accent_color: color });
  };

  const bgClass = BACKGROUND_THEMES.find((t) => t.id === backgroundTheme)?.className || 'bg-theme-aurora';

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme, backgroundTheme, setBackgroundTheme, accentColor, setAccentColor }}>
      <div className={`min-h-screen ${bgClass} transition-all duration-500`}>
        {children}
      </div>
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error('useTheme must be used within ThemeProvider');
  return ctx;
}
