/*
# Create edits table

The upload membership is for uploading EDITS (with quality and FPS settings),
not scenepacks. This table stores user-uploaded edits.

## New Tables
1. **edits** — user-uploaded video edits with quality and FPS metadata
   - id (uuid, primary key)
   - title (text, not null)
   - description (text, default '')
   - video_url (text, nullable) — link to the edit video
   - thumbnail_url (text, nullable)
   - quality (text, not null, default '1080p') — e.g. 720p, 1080p, 1440p, 4K
   - fps (integer, not null, default 60) — e.g. 24, 30, 60, 120
   - creator_id (uuid, FK to profiles, default auth.uid())
   - downloads (integer, default 0)
   - views (integer, default 0)
   - created_at (timestamptz, default now())
   - updated_at (timestamptz, default now())

## Security (RLS)
- SELECT: public (anon + authenticated) — edits are visible to everyone
- INSERT: authenticated users with active subscription OR admin
- UPDATE: owner or admin
- DELETE: owner or admin

## Notes
- Only users with an active subscription (upload membership) or admins can insert edits.
- The `creator_id` defaults to `auth.uid()` so inserts work without passing it explicitly.
*/

CREATE TABLE IF NOT EXISTS public.edits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL DEFAULT '',
  video_url text,
  thumbnail_url text,
  quality text NOT NULL DEFAULT '1080p',
  fps integer NOT NULL DEFAULT 60,
  creator_id uuid NOT NULL DEFAULT auth.uid() REFERENCES public.profiles(id) ON DELETE CASCADE,
  downloads integer NOT NULL DEFAULT 0,
  views integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.edits ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "edits_select_all" ON public.edits;
CREATE POLICY "edits_select_all" ON public.edits FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "edits_insert_subscribed" ON public.edits;
CREATE POLICY "edits_insert_subscribed" ON public.edits FOR INSERT
  TO authenticated WITH CHECK (
    public.is_admin()
    OR EXISTS (
      SELECT 1 FROM public.subscriptions
      WHERE subscriptions.user_id = auth.uid()
        AND subscriptions.status = 'active'
        AND subscriptions.end_date > now()
    )
  );

DROP POLICY IF EXISTS "edits_update_own_admin" ON public.edits;
CREATE POLICY "edits_update_own_admin" ON public.edits FOR UPDATE
  TO authenticated USING (auth.uid() = creator_id OR public.is_admin())
  WITH CHECK (auth.uid() = creator_id OR public.is_admin());

DROP POLICY IF EXISTS "edits_delete_own_admin" ON public.edits;
CREATE POLICY "edits_delete_own_admin" ON public.edits FOR DELETE
  TO authenticated USING (auth.uid() = creator_id OR public.is_admin());

CREATE INDEX IF NOT EXISTS idx_edits_creator ON public.edits(creator_id);
CREATE INDEX IF NOT EXISTS idx_edits_created ON public.edits(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_edits_quality ON public.edits(quality);
CREATE INDEX IF NOT EXISTS idx_edits_fps ON public.edits(fps);
