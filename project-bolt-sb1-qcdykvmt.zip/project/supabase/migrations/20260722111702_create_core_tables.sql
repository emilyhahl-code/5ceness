/*
# 5CENES — Core Content & Community Tables

Creates all remaining tables for the 5CENES platform: scenepacks, tutorials,
requests, comments, likes, ratings, favorites, subscriptions, orders,
announcements, news, follows, notifications, achievements, user_achievements.

## Helper Functions
- **is_admin()** — returns true if current user's profile has is_admin = true (SECURITY DEFINER)

## New Tables
1. **scenepacks** — free downloadable scenepacks with categories, counters, trending flag
2. **tutorials** — video tutorials with views counter
3. **requests** — community feature requests with status workflow
4. **comments** — polymorphic comments (scenepack/tutorial/request) with nested replies
5. **likes** — polymorphic likes (scenepack/tutorial/request/comment)
6. **ratings** — 5-star ratings on scenepacks (one per user per scenepack)
7. **favorites** — user's favorited scenepacks
8. **subscriptions** — upload membership records (€1.50/month PayPal)
9. **orders** — website service orders (Basic €45 / Premium up to €100)
10. **announcements** — admin-published announcements
11. **news** — admin-published news articles
12. **follows** — user follow relationships
13. **notifications** — user notifications
14. **achievements** — definable achievements
15. **user_achievements** — achievements earned by users

## Security (RLS)
- Public content (scenepacks, tutorials, news, announcements, achievements, follows,
  comments, likes, ratings): SELECT to anon + authenticated.
- Private data (favorites, subscriptions, orders, notifications): SELECT to owner/admin.
- Admin-only writes for: scenepacks, tutorials, announcements, news, achievements CRUD.
- All tables have RLS enabled. 4 separate policies per table.
*/

-- ============================================================
-- HELPER FUNCTION
-- ============================================================

CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND is_admin = true
  );
$$;

-- ============================================================
-- SCENEPACKS
-- ============================================================

CREATE TABLE IF NOT EXISTS public.scenepacks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL DEFAULT '',
  category text NOT NULL DEFAULT 'General',
  thumbnail_url text,
  download_url text,
  creator_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  downloads integer NOT NULL DEFAULT 0,
  views integer NOT NULL DEFAULT 0,
  trending boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.scenepacks ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "scenepacks_select_all" ON public.scenepacks;
CREATE POLICY "scenepacks_select_all" ON public.scenepacks FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "scenepacks_insert_admin" ON public.scenepacks;
CREATE POLICY "scenepacks_insert_admin" ON public.scenepacks FOR INSERT
  TO authenticated WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "scenepacks_update_admin" ON public.scenepacks;
CREATE POLICY "scenepacks_update_admin" ON public.scenepacks FOR UPDATE
  TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "scenepacks_delete_admin" ON public.scenepacks;
CREATE POLICY "scenepacks_delete_admin" ON public.scenepacks FOR DELETE
  TO authenticated USING (public.is_admin());

-- ============================================================
-- TUTORIALS
-- ============================================================

CREATE TABLE IF NOT EXISTS public.tutorials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL DEFAULT '',
  video_url text,
  thumbnail_url text,
  creator_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  views integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.tutorials ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "tutorials_select_all" ON public.tutorials;
CREATE POLICY "tutorials_select_all" ON public.tutorials FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "tutorials_insert_admin" ON public.tutorials;
CREATE POLICY "tutorials_insert_admin" ON public.tutorials FOR INSERT
  TO authenticated WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "tutorials_update_admin" ON public.tutorials;
CREATE POLICY "tutorials_update_admin" ON public.tutorials FOR UPDATE
  TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "tutorials_delete_admin" ON public.tutorials;
CREATE POLICY "tutorials_delete_admin" ON public.tutorials FOR DELETE
  TO authenticated USING (public.is_admin());

-- ============================================================
-- REQUESTS
-- ============================================================

CREATE TABLE IF NOT EXISTS public.requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL DEFAULT '',
  category text NOT NULL DEFAULT 'General',
  status text NOT NULL DEFAULT 'open',
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES public.profiles(id) ON DELETE CASCADE,
  votes integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT requests_status_check CHECK (status IN ('open', 'in_progress', 'completed'))
);

ALTER TABLE public.requests ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "requests_select_all" ON public.requests;
CREATE POLICY "requests_select_all" ON public.requests FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "requests_insert_own" ON public.requests;
CREATE POLICY "requests_insert_own" ON public.requests FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "requests_update_own_admin" ON public.requests;
CREATE POLICY "requests_update_own_admin" ON public.requests FOR UPDATE
  TO authenticated USING (auth.uid() = user_id OR public.is_admin()) WITH CHECK (auth.uid() = user_id OR public.is_admin());

DROP POLICY IF EXISTS "requests_delete_own_admin" ON public.requests;
CREATE POLICY "requests_delete_own_admin" ON public.requests FOR DELETE
  TO authenticated USING (auth.uid() = user_id OR public.is_admin());

-- ============================================================
-- COMMENTS (polymorphic)
-- ============================================================

CREATE TABLE IF NOT EXISTS public.comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  content text NOT NULL,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES public.profiles(id) ON DELETE CASCADE,
  target_type text NOT NULL,
  target_id uuid NOT NULL,
  parent_id uuid REFERENCES public.comments(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT comments_target_type_check CHECK (target_type IN ('scenepack', 'tutorial', 'request'))
);

ALTER TABLE public.comments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "comments_select_all" ON public.comments;
CREATE POLICY "comments_select_all" ON public.comments FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "comments_insert_own" ON public.comments;
CREATE POLICY "comments_insert_own" ON public.comments FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "comments_update_own_admin" ON public.comments;
CREATE POLICY "comments_update_own_admin" ON public.comments FOR UPDATE
  TO authenticated USING (auth.uid() = user_id OR public.is_admin()) WITH CHECK (auth.uid() = user_id OR public.is_admin());

DROP POLICY IF EXISTS "comments_delete_own_admin" ON public.comments;
CREATE POLICY "comments_delete_own_admin" ON public.comments FOR DELETE
  TO authenticated USING (auth.uid() = user_id OR public.is_admin());

-- ============================================================
-- LIKES (polymorphic)
-- ============================================================

CREATE TABLE IF NOT EXISTS public.likes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES public.profiles(id) ON DELETE CASCADE,
  target_type text NOT NULL,
  target_id uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, target_type, target_id),
  CONSTRAINT likes_target_type_check CHECK (target_type IN ('scenepack', 'tutorial', 'request', 'comment'))
);

ALTER TABLE public.likes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "likes_select_all" ON public.likes;
CREATE POLICY "likes_select_all" ON public.likes FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "likes_insert_own" ON public.likes;
CREATE POLICY "likes_insert_own" ON public.likes FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "likes_delete_own" ON public.likes;
CREATE POLICY "likes_delete_own" ON public.likes FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ============================================================
-- RATINGS (scenepack only, 1-5 stars)
-- ============================================================

CREATE TABLE IF NOT EXISTS public.ratings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES public.profiles(id) ON DELETE CASCADE,
  scenepack_id uuid NOT NULL REFERENCES public.scenepacks(id) ON DELETE CASCADE,
  rating integer NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, scenepack_id),
  CONSTRAINT ratings_rating_check CHECK (rating >= 1 AND rating <= 5)
);

ALTER TABLE public.ratings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "ratings_select_all" ON public.ratings;
CREATE POLICY "ratings_select_all" ON public.ratings FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "ratings_insert_own" ON public.ratings;
CREATE POLICY "ratings_insert_own" ON public.ratings FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "ratings_update_own" ON public.ratings;
CREATE POLICY "ratings_update_own" ON public.ratings FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "ratings_delete_own" ON public.ratings;
CREATE POLICY "ratings_delete_own" ON public.ratings FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ============================================================
-- FAVORITES
-- ============================================================

CREATE TABLE IF NOT EXISTS public.favorites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES public.profiles(id) ON DELETE CASCADE,
  scenepack_id uuid NOT NULL REFERENCES public.scenepacks(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, scenepack_id)
);

ALTER TABLE public.favorites ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "favorites_select_own" ON public.favorites;
CREATE POLICY "favorites_select_own" ON public.favorites FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "favorites_insert_own" ON public.favorites;
CREATE POLICY "favorites_insert_own" ON public.favorites FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "favorites_delete_own" ON public.favorites;
CREATE POLICY "favorites_delete_own" ON public.favorites FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ============================================================
-- SUBSCRIPTIONS (Upload Membership €1.50/month)
-- ============================================================

CREATE TABLE IF NOT EXISTS public.subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES public.profiles(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'active',
  start_date timestamptz NOT NULL DEFAULT now(),
  end_date timestamptz NOT NULL DEFAULT (now() + interval '1 month'),
  amount numeric NOT NULL DEFAULT 1.50,
  payment_method text NOT NULL DEFAULT 'paypal',
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT subscriptions_status_check CHECK (status IN ('active', 'expired', 'cancelled'))
);

ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "subscriptions_select_own_admin" ON public.subscriptions;
CREATE POLICY "subscriptions_select_own_admin" ON public.subscriptions FOR SELECT
  TO authenticated USING (auth.uid() = user_id OR public.is_admin());

DROP POLICY IF EXISTS "subscriptions_insert_own" ON public.subscriptions;
CREATE POLICY "subscriptions_insert_own" ON public.subscriptions FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "subscriptions_update_admin" ON public.subscriptions;
CREATE POLICY "subscriptions_update_admin" ON public.subscriptions FOR UPDATE
  TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "subscriptions_delete_admin" ON public.subscriptions;
CREATE POLICY "subscriptions_delete_admin" ON public.subscriptions FOR DELETE
  TO authenticated USING (public.is_admin());

-- ============================================================
-- ORDERS (Website Services)
-- ============================================================

CREATE TABLE IF NOT EXISTS public.orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  customer_name text NOT NULL,
  customer_email text NOT NULL,
  service_tier text NOT NULL DEFAULT 'basic',
  price numeric NOT NULL DEFAULT 45,
  requirements text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT orders_service_tier_check CHECK (service_tier IN ('basic', 'premium')),
  CONSTRAINT orders_status_check CHECK (status IN ('pending', 'in_progress', 'completed', 'cancelled'))
);

ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "orders_select_own_admin" ON public.orders;
CREATE POLICY "orders_select_own_admin" ON public.orders FOR SELECT
  TO authenticated USING (auth.uid() = user_id OR public.is_admin());

DROP POLICY IF EXISTS "orders_insert_all" ON public.orders;
CREATE POLICY "orders_insert_all" ON public.orders FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "orders_update_admin" ON public.orders;
CREATE POLICY "orders_update_admin" ON public.orders FOR UPDATE
  TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "orders_delete_admin" ON public.orders;
CREATE POLICY "orders_delete_admin" ON public.orders FOR DELETE
  TO authenticated USING (public.is_admin());

-- ============================================================
-- ANNOUNCEMENTS
-- ============================================================

CREATE TABLE IF NOT EXISTS public.announcements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  content text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "announcements_select_all" ON public.announcements;
CREATE POLICY "announcements_select_all" ON public.announcements FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "announcements_insert_admin" ON public.announcements;
CREATE POLICY "announcements_insert_admin" ON public.announcements FOR INSERT
  TO authenticated WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "announcements_update_admin" ON public.announcements;
CREATE POLICY "announcements_update_admin" ON public.announcements FOR UPDATE
  TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "announcements_delete_admin" ON public.announcements;
CREATE POLICY "announcements_delete_admin" ON public.announcements FOR DELETE
  TO authenticated USING (public.is_admin());

-- ============================================================
-- NEWS
-- ============================================================

CREATE TABLE IF NOT EXISTS public.news (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  content text NOT NULL,
  image_url text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.news ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "news_select_all" ON public.news;
CREATE POLICY "news_select_all" ON public.news FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "news_insert_admin" ON public.news;
CREATE POLICY "news_insert_admin" ON public.news FOR INSERT
  TO authenticated WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "news_update_admin" ON public.news;
CREATE POLICY "news_update_admin" ON public.news FOR UPDATE
  TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "news_delete_admin" ON public.news;
CREATE POLICY "news_delete_admin" ON public.news FOR DELETE
  TO authenticated USING (public.is_admin());

-- ============================================================
-- FOLLOWS
-- ============================================================

CREATE TABLE IF NOT EXISTS public.follows (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  follower_id uuid NOT NULL DEFAULT auth.uid() REFERENCES public.profiles(id) ON DELETE CASCADE,
  following_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (follower_id, following_id),
  CONSTRAINT follows_no_self CHECK (follower_id != following_id)
);

ALTER TABLE public.follows ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "follows_select_all" ON public.follows;
CREATE POLICY "follows_select_all" ON public.follows FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "follows_insert_own" ON public.follows;
CREATE POLICY "follows_insert_own" ON public.follows FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = follower_id);

DROP POLICY IF EXISTS "follows_delete_own" ON public.follows;
CREATE POLICY "follows_delete_own" ON public.follows FOR DELETE
  TO authenticated USING (auth.uid() = follower_id);

-- ============================================================
-- NOTIFICATIONS
-- ============================================================

CREATE TABLE IF NOT EXISTS public.notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  type text NOT NULL,
  message text NOT NULL,
  link text,
  read boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT notifications_type_check CHECK (type IN ('like', 'comment', 'follow', 'reply', 'system'))
);

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "notifications_select_own" ON public.notifications;
CREATE POLICY "notifications_select_own" ON public.notifications FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "notifications_insert_authenticated" ON public.notifications;
CREATE POLICY "notifications_insert_authenticated" ON public.notifications FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "notifications_update_own" ON public.notifications;
CREATE POLICY "notifications_update_own" ON public.notifications FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "notifications_delete_own" ON public.notifications;
CREATE POLICY "notifications_delete_own" ON public.notifications FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ============================================================
-- ACHIEVEMENTS
-- ============================================================

CREATE TABLE IF NOT EXISTS public.achievements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text NOT NULL,
  icon text NOT NULL DEFAULT 'Award',
  requirement text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.achievements ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "achievements_select_all" ON public.achievements;
CREATE POLICY "achievements_select_all" ON public.achievements FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "achievements_insert_admin" ON public.achievements;
CREATE POLICY "achievements_insert_admin" ON public.achievements FOR INSERT
  TO authenticated WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "achievements_update_admin" ON public.achievements;
CREATE POLICY "achievements_update_admin" ON public.achievements FOR UPDATE
  TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "achievements_delete_admin" ON public.achievements;
CREATE POLICY "achievements_delete_admin" ON public.achievements FOR DELETE
  TO authenticated USING (public.is_admin());

-- ============================================================
-- USER ACHIEVEMENTS
-- ============================================================

CREATE TABLE IF NOT EXISTS public.user_achievements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES public.profiles(id) ON DELETE CASCADE,
  achievement_id uuid NOT NULL REFERENCES public.achievements(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, achievement_id)
);

ALTER TABLE public.user_achievements ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "user_achievements_select_all" ON public.user_achievements;
CREATE POLICY "user_achievements_select_all" ON public.user_achievements FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "user_achievements_insert_admin" ON public.user_achievements;
CREATE POLICY "user_achievements_insert_admin" ON public.user_achievements FOR INSERT
  TO authenticated WITH CHECK (public.is_admin() OR auth.uid() = user_id);

DROP POLICY IF EXISTS "user_achievements_delete_admin" ON public.user_achievements;
CREATE POLICY "user_achievements_delete_admin" ON public.user_achievements FOR DELETE
  TO authenticated USING (public.is_admin());

-- ============================================================
-- INDEXES
-- ============================================================

CREATE INDEX IF NOT EXISTS idx_scenepacks_category ON public.scenepacks(category);
CREATE INDEX IF NOT EXISTS idx_scenepacks_trending ON public.scenepacks(trending);
CREATE INDEX IF NOT EXISTS idx_scenepacks_created ON public.scenepacks(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_tutorials_created ON public.tutorials(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_requests_status ON public.requests(status);
CREATE INDEX IF NOT EXISTS idx_requests_votes ON public.requests(votes DESC);
CREATE INDEX IF NOT EXISTS idx_comments_target ON public.comments(target_type, target_id);
CREATE INDEX IF NOT EXISTS idx_comments_parent ON public.comments(parent_id);
CREATE INDEX IF NOT EXISTS idx_likes_target ON public.likes(target_type, target_id);
CREATE INDEX IF NOT EXISTS idx_likes_user ON public.likes(user_id);
CREATE INDEX IF NOT EXISTS idx_ratings_scenepack ON public.ratings(scenepack_id);
CREATE INDEX IF NOT EXISTS idx_favorites_user ON public.favorites(user_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_user ON public.subscriptions(user_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_status ON public.subscriptions(status);
CREATE INDEX IF NOT EXISTS idx_orders_status ON public.orders(status);
CREATE INDEX IF NOT EXISTS idx_follows_follower ON public.follows(follower_id);
CREATE INDEX IF NOT EXISTS idx_follows_following ON public.follows(following_id);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON public.notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_read ON public.notifications(read);
CREATE INDEX IF NOT EXISTS idx_news_created ON public.news(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_announcements_created ON public.announcements(created_at DESC);
